import React from 'react';
import { StatCard, SectionHeader } from '../../components/DashboardElements';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Legend } from 'recharts';
import { DollarSign, Wallet, FileText, TrendingUp, Landmark, PieChart } from 'lucide-react';

const Dashboard = () => {
  const collectionData = [
    { name: 'Mon', collection: 4000 },
    { name: 'Tue', collection: 3000 },
    { name: 'Wed', collection: 2000 },
    { name: 'Thu', collection: 2780 },
    { name: 'Fri', collection: 1890 },
    { name: 'Sat', collection: 2390 },
    { name: 'Sun', collection: 3490 },
  ];

  const revenueExpenseData = [
    { name: 'Jan', revenue: 4000, expense: 2400 },
    { name: 'Feb', revenue: 3000, expense: 1398 },
    { name: 'Mar', revenue: 2000, expense: 9800 },
    { name: 'Apr', revenue: 2780, expense: 3908 },
  ];

  const quickActions = [
    { label: 'View Pending Invoices', icon: FileText, color: '#3b82f6', bg: '#eff6ff' },
    { label: 'Add Expense', icon: Wallet, color: '#ef4444', bg: '#fef2f2' },
    { label: 'Generate Report', icon: PieChart, color: '#7c3aed', bg: '#f5f3ff' },
  ];

  return (
    <div className="fade-in">
      <SectionHeader title="Accountant Dashboard" desc="Welcome back, Kushal Dev. Manage clinic finances and payouts." />

      {/* UI CARDS */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1.25rem', marginBottom: '2rem' }}>
        <StatCard title="Today Collection" value="$ 12,400" color="#3b82f6" icon={DollarSign} />
        <StatCard title="Monthly Revenue" value="$ 42.5K" color="#10b981" icon={TrendingUp} />
        <StatCard title="Pending Dues" value="$ 11.5K" color="#f59e0b" icon={FileText} />
        <StatCard title="Total Expenses" value="$ 65,000" color="#ef4444" icon={Wallet} />
        <StatCard title="Doctor Payable" value="$ 45,800" color="#8b5cf6" icon={Landmark} />
      </div>

      {/* QUICK ACTIONS */}


      <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: '1.5rem' }}>
        {/* Collection Chart */}
        <div className="card">
          <h3 style={{ marginBottom: '1.5rem' }}>Collection (Month wise)</h3>
          <div style={{ height: '300px' }}>
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={collectionData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Area type="monotone" dataKey="collection" stroke="#3b82f6" fill="#bfdbfe" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Expenses vs Revenue Chart */}
        <div className="card">
          <h3 style={{ marginBottom: '1.5rem' }}>Expenses vs Revenue</h3>
          <div style={{ height: '300px' }}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={revenueExpenseData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="revenue" fill="#10b981" />
                <Bar dataKey="expense" fill="#ef4444" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
