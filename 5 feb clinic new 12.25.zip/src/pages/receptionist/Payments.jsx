import React, { useState } from 'react';
import { Eye, Printer, CreditCard, Search, Calendar } from 'lucide-react';
import { SectionHeader } from '../../components/DashboardElements';
import { MOCK_PAYMENTS, MOCK_INVOICES } from '../../data/mockData';
import Drawer from '../../components/Drawer.jsx';

const Payments = () => {
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  const labelStyle = {
    display: 'block',
    fontSize: '0.75rem',
    fontWeight: 700,
    color: '#94a3b8',
    textTransform: 'uppercase',
    marginBottom: '0.3rem'
  };

  const inputStyle = {
    width: '100%',
    padding: '0.75rem',
    borderRadius: '10px',
    border: '1px solid #e2e8f0',
    fontSize: '0.9rem',
    outline: 'none',
  };

  return (
    <div className="fade-in">
      <SectionHeader
        title="Payments"
        desc="Collect and track patient payments."
        actionLabel="Collect Payment"
        onAction={() => setIsDrawerOpen(true)}
      />

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>Receipt No</th>
              <th>Invoice No</th>
              <th>Patient</th>
              <th>Amount</th>
              <th>Mode</th>
              <th>Date</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {MOCK_PAYMENTS.map(p => (
              <tr key={p.id}>
                <td><span style={{ fontWeight: 600, color: '#6366f1' }}>{p.txId}</span></td>
                <td>{p.invId}</td>
                <td><b>{p.clinic}</b></td>
                <td style={{ fontWeight: 700 }}>{p.amount}</td>
                <td><span className="badge badge-blue">{p.mode}</span></td>
                <td>{p.date}</td>
                <td>
                  <div style={{ display: 'flex', gap: '0.5rem' }}>
                    <button className="action-btn" title="View"><Eye size={16} color="#6366f1" /></button>
                    <button className="action-btn" title="Print"><Printer size={16} color="#64748b" /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Drawer isOpen={isDrawerOpen} onClose={() => setIsDrawerOpen(false)} title="Collect Payment">
        <form style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          <div>
            <label style={labelStyle}>Invoice Number *</label>
            <select style={inputStyle}>
              <option>Search Invoice...</option>
              {MOCK_INVOICES.map(inv => <option key={inv.id}>{inv.invId} - {inv.patient} ({inv.total})</option>)}
            </select>
          </div>
          <div>
            <label style={labelStyle}>Amount to Collect ($) *</label>
            <input type="number" placeholder="0.00" style={inputStyle} required />
          </div>
          <div>
            <label style={labelStyle}>Payment Mode *</label>
            <select style={inputStyle}>
              <option>Cash</option>
              <option>UPI</option>
              <option>Card</option>
            </select>
          </div>
          <div>
            <label style={labelStyle}>Transaction ID (Optional)</label>
            <input type="text" placeholder="TXN12345678" style={inputStyle} />
          </div>
          <div>
            <label style={labelStyle}>Payment Date</label>
            <input type="date" defaultValue={new Date().toISOString().split('T')[0]} style={inputStyle} />
          </div>
          <div style={{ display: 'flex', gap: '1rem', marginTop: '1rem' }}>
            <button className="btn-primary" style={{ flex: 1, backgroundColor: '#7c3aed', color: 'white', padding: '1rem', borderRadius: '12px', fontWeight: 700 }}>Save Payment</button>
            <button type="button" style={{ flex: 1, backgroundColor: '#f1f5f9', color: '#64748b', padding: '1rem', borderRadius: '12px', fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem' }}>
              <Printer size={18} /> Print Receipt
            </button>
          </div>
        </form>
      </Drawer>
    </div>
  );
};

export default Payments;
