import React, { useState } from 'react';
import { Eye, Edit, FileText, UserPlus, Search, Filter, Phone, Mail, MapPin, Calendar, Activity, Receipt, ClipboardList, Plus, Trash2 } from 'lucide-react';
import { SectionHeader } from '../../components/DashboardElements';
import { MOCK_PATIENTS, MOCK_APPOINTMENTS, MOCK_INVOICES } from '../../data/mockData';
import Drawer from '../../components/Drawer.jsx';

const Patients = () => {
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [viewType, setViewType] = useState('add'); // add, view
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [activeTab, setActiveTab] = useState('info');
  const [searchTerm, setSearchTerm] = useState('');
  const [genderFilter, setGenderFilter] = useState('All');

  const inputStyle = {
    width: '100%',
    padding: '0.75rem',
    borderRadius: '10px',
    border: '1px solid #e2e8f0',
    fontSize: '0.9rem',
    outline: 'none',
  };

  const labelStyle = {
    display: 'block',
    fontSize: '0.8rem',
    fontWeight: 700,
    color: 'var(--text-muted)',
    marginBottom: '0.4rem',
    textTransform: 'uppercase',
  };

  const filteredPatients = MOCK_PATIENTS.filter(patient => {
    const matchesSearch = patient.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      patient.patientId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      patient.mobile.includes(searchTerm);
    const matchesGender = genderFilter === 'All' || patient.gender === genderFilter;
    return matchesSearch && matchesGender;
  });

  const handleAddPatient = () => {
    setViewType('add');
    setSelectedPatient(null);
    setIsDrawerOpen(true);
  };

  const handleViewPatient = (patient) => {
    setViewType('view');
    setSelectedPatient(patient);
    setActiveTab('info');
    setIsDrawerOpen(true);
  };

  return (
    <div className="fade-in">
      <SectionHeader
        title="Patients"
        desc="Manage all patient records and histories."
        actionLabel="Add Patient"
        onAction={handleAddPatient}
      />

      <div className="card" style={{ marginBottom: '1.5rem', padding: '1rem', backgroundColor: 'var(--bg-sidebar)' }}>
        <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
          <div style={{ flex: 1, minWidth: '250px', position: 'relative' }}>
            <Search size={18} color="#94a3b8" style={{ position: 'absolute', left: '1rem', top: '50%', transform: 'translateY(-50%)' }} />
            <input
              type="text"
              placeholder="Search by name, ID or mobile..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              style={{ ...inputStyle, paddingLeft: '2.8rem', backgroundColor: 'var(--bg-main)', color: 'var(--text-main)' }}
            />
          </div>
          <select
            value={genderFilter}
            onChange={(e) => setGenderFilter(e.target.value)}
            style={{ padding: '0 1rem', borderRadius: '10px', border: '1px solid var(--border)', backgroundColor: 'var(--bg-main)', color: 'var(--text-main)', outline: 'none', height: '44px' }}
          >
            <option value="All">All Gender</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
          </select>
        </div>
      </div>

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>Patient ID</th>
              <th>Patient Name</th>
              <th>Mobile</th>
              <th>Gender</th>
              <th>Last Visit</th>
              <th>Due Amount</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {filteredPatients.map(patient => (
              <tr key={patient.id}>
                <td data-label="Patient ID"><span style={{ fontWeight: 600, color: 'var(--text-muted)' }}>{patient.patientId}</span></td>
                <td data-label="Patient Name"><b>{patient.name}</b></td>
                <td data-label="Mobile">{patient.mobile}</td>
                <td data-label="Gender">{patient.gender}</td>
                <td data-label="Last Visit">{patient.lastVisit}</td>
                <td data-label="Due Amount" style={{ color: patient.dueAmount !== '₹ 0' ? 'var(--danger)' : 'var(--accent)', fontWeight: 700 }}>{patient.dueAmount}</td>
                <td data-label="Status">
                  <span className={`badge ${patient.status === 'Active' ? 'badge-success' : 'badge-danger'}`}>
                    {patient.status}
                  </span>
                </td>
                <td data-label="Actions">
                  <div style={{ display: 'flex', gap: '0.5rem' }}>
                    <button className="action-btn" onClick={() => handleViewPatient(patient)} title="View Profile"><Eye size={18} color="var(--primary)" /></button>
                    <button className="action-btn" title="Edit" onClick={() => { setViewType('add'); setSelectedPatient(patient); setIsDrawerOpen(true); }}><Edit size={18} color="var(--secondary)" /></button>
                    <button className="action-btn" title="Create Invoice" onClick={() => alert('Opening Invoice Generator for ' + patient.name)}><FileText size={18} color="#10b981" /></button>
                    <button className="action-btn" title="Delete" onClick={() => confirm('Are you sure?') && alert('Patient record deleted')}><Trash2 size={18} color="var(--danger)" /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Drawer
        isOpen={isDrawerOpen}
        onClose={() => setIsDrawerOpen(false)}
        title={viewType === 'add' ? "Add Patient" : "Patient Profile"}
      >
        {viewType === 'add' ? (
          <form style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <div style={{ gridColumn: 'span 2' }}>
                <label style={labelStyle}>Full Name *</label>
                <input type="text" placeholder="Enter patient's full name" style={inputStyle} required />
              </div>
              <div>
                <label style={labelStyle}>Mobile Number *</label>
                <input type="tel" placeholder="00000 00000" style={inputStyle} required />
              </div>
              <div>
                <label style={labelStyle}>Email</label>
                <input type="email" placeholder="patient@example.com" style={inputStyle} />
              </div>
              <div>
                <label style={labelStyle}>Gender</label>
                <select style={inputStyle}>
                  <option>Male</option>
                  <option>Female</option>
                  <option>Other</option>
                </select>
              </div>
              <div>
                <label style={labelStyle}>Date of Birth / Age</label>
                <input type="text" placeholder="e.g. 25" style={inputStyle} />
              </div>
              <div>
                <label style={labelStyle}>Blood Group</label>
                <select style={inputStyle}>
                  <option>Select</option>
                  <option>A+</option><option>A-</option>
                  <option>B+</option><option>B-</option>
                  <option>O+</option><option>O-</option>
                  <option>AB+</option><option>AB-</option>
                </select>
              </div>
              <div style={{ gridColumn: 'span 2', marginTop: '1rem', borderTop: '1px solid #e2e8f0', paddingTop: '1rem' }}>
                <p style={{ fontSize: '0.85rem', fontWeight: 600, color: '#64748b', marginBottom: '0.75rem' }}>Login Credentials</p>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                  <div>
                    <label style={labelStyle}>Login Email *</label>
                    <input type="email" placeholder="login@email.com" style={inputStyle} required />
                  </div>
                  <div>
                    <label style={labelStyle}>Password *</label>
                    <input type="password" placeholder="Create Password" style={inputStyle} required />
                  </div>
                </div>
              </div>
              <div style={{ gridColumn: 'span 2' }}>
                <label style={labelStyle}>Address</label>
                <textarea placeholder="Full Address" style={{ ...inputStyle, height: '60px', resize: 'none' }} />
              </div>
              <div style={{ gridColumn: 'span 2' }}>
                <label style={labelStyle}>Emergency Contact Name</label>
                <input type="text" placeholder="Contact Name" style={inputStyle} />
              </div>
              <div style={{ gridColumn: 'span 2' }}>
                <label style={labelStyle}>Emergency Contact Number</label>
                <input type="tel" placeholder="Contact Number" style={inputStyle} />
              </div>
            </div>

            <div style={{ display: 'flex', gap: '1rem', marginTop: '1rem' }}>
              <button className="btn-primary" style={{ flex: 1, backgroundColor: '#7c3aed', color: 'white', padding: '1rem', borderRadius: '12px', fontWeight: 700 }}>Save</button>
              <button className="btn-secondary" style={{ flex: 1, backgroundColor: '#f5f3ff', color: '#7c3aed', padding: '1rem', borderRadius: '12px', fontWeight: 600 }}>Save & Book Appointment</button>
              <button type="button" onClick={() => setIsDrawerOpen(false)} style={{ backgroundColor: '#fee2e2', color: '#ef4444', padding: '1rem', borderRadius: '12px', fontWeight: 600 }}>Cancel</button>
            </div>
          </form>
        ) : selectedPatient && (
          <div style={{ padding: '0.5rem' }}>
            <div style={{ display: 'flex', gap: '1.5rem', alignItems: 'center', marginBottom: '2rem' }}>
              <div style={{ width: '80px', height: '80px', borderRadius: '20px', backgroundColor: 'var(--bg-header)', color: 'var(--primary)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '2rem', fontWeight: 800 }}>
                {selectedPatient.name.charAt(0)}
              </div>
              <div>
                <h2 style={{ fontSize: '1.5rem', color: 'var(--heading)' }}>{selectedPatient.name}</h2>
                <p style={{ color: 'var(--text-muted)', fontWeight: 600 }}>{selectedPatient.patientId}</p>
              </div>
            </div>

            <div style={{ display: 'flex', borderBottom: '1px solid var(--border)', marginBottom: '1.5rem' }}>
              {[
                { id: 'info', label: 'Personal Info' },
                { id: 'history', label: 'Appointment History' },
                { id: 'bills', label: 'Bills & Payments' },
                { id: 'rx', label: 'Prescriptions' },
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  style={{
                    padding: '1rem 1.25rem',
                    color: activeTab === tab.id ? 'var(--primary)' : 'var(--text-muted)',
                    borderBottom: `2px solid ${activeTab === tab.id ? 'var(--primary)' : 'transparent'}`,
                    fontWeight: 600,
                    fontSize: '0.9rem',
                    backgroundColor: 'transparent'
                  }}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            <div style={{ minHeight: '300px' }}>
              {activeTab === 'info' && (
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
                  <div><label style={labelStyle}>Gender</label><p>{selectedPatient.gender}</p></div>
                  <div><label style={labelStyle}>Age</label><p>{selectedPatient.age} years</p></div>
                  <div><label style={labelStyle}>Blood Group</label><p>{selectedPatient.bloodGroup}</p></div>
                  <div><label style={labelStyle}>Mobile</label><p>{selectedPatient.mobile}</p></div>
                  <div style={{ gridColumn: 'span 2' }}><label style={labelStyle}>Address</label><p>123 Clinic St, Medical Area, New Delhi</p></div>
                </div>
              )}
              {activeTab === 'history' && (
                <div>
                  {MOCK_APPOINTMENTS.map((app, i) => (
                    <div key={i} style={{ padding: '1rem', border: '1px solid #f1f5f9', borderRadius: '12px', marginBottom: '0.75rem' }}>
                      <p style={{ fontWeight: 700 }}>{app.date} • {app.time}</p>
                      <p style={{ color: '#64748b' }}>{app.doctor} • {app.type}</p>
                    </div>
                  ))}
                </div>
              )}
              {activeTab === 'bills' && (
                <div>
                  {MOCK_INVOICES.map((inv, i) => (
                    <div key={i} style={{ padding: '1rem', border: '1px solid var(--border)', borderRadius: '12px', marginBottom: '0.75rem', display: 'flex', justifyContent: 'space-between', backgroundColor: 'var(--bg-main)' }}>
                      <div>
                        <p style={{ fontWeight: 700, color: 'var(--heading)' }}>{inv.invId}</p>
                        <p style={{ color: 'var(--text-muted)' }}>{inv.date}</p>
                      </div>
                      <div style={{ textAlign: 'right' }}>
                        <p style={{ fontWeight: 800, color: 'var(--primary)' }}>{inv.total}</p>
                        <span className={`badge ${inv.status === 'Paid' ? 'badge-success' : 'badge-warning'}`}>{inv.status}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
              {activeTab === 'rx' && <p style={{ textAlign: 'center', color: '#94a3b8', marginTop: '2rem' }}>No prescriptions found.</p>}
            </div>
          </div>
        )}
      </Drawer>
    </div>
  );
};

export default Patients;
