import React, { useState } from 'react';
import { User, Shield, Bell, Save, LogOut, Clock, Calendar, CheckCircle } from 'lucide-react';
import { SectionHeader } from '../../components/DashboardElements';

const Settings = () => {
  const [activeTab, setActiveTab] = useState('profile');

  const inputStyle = {
    width: '100%',
    padding: '0.75rem',
    borderRadius: '10px',
    border: '1px solid #e2e8f0',
    fontSize: '0.9rem',
    outline: 'none',
  };

  const labelStyle = {
    display: 'block',
    fontSize: '0.8rem',
    fontWeight: 700,
    color: '#475569',
    marginBottom: '0.4rem',
    textTransform: 'uppercase',
  };

  return (
    <div className="fade-in">
      <SectionHeader title="Profile & Settings" desc="Manage your personal information and account preferences." />

      <div style={{ display: 'flex', gap: '1rem', borderBottom: '1px solid #e2e8f0', marginBottom: '2rem' }}>
        <button onClick={() => setActiveTab('profile')} style={{ padding: '1rem', color: activeTab === 'profile' ? '#7c3aed' : '#94a3b8', borderBottom: `2px solid ${activeTab === 'profile' ? '#7c3aed' : 'transparent'}`, fontWeight: 600, backgroundColor: 'transparent' }}>
          Doctor Profile
        </button>
        <button onClick={() => setActiveTab('account')} style={{ padding: '1rem', color: activeTab === 'account' ? '#7c3aed' : '#94a3b8', borderBottom: `2px solid ${activeTab === 'account' ? '#7c3aed' : 'transparent'}`, fontWeight: 600, backgroundColor: 'transparent' }}>
          Account Settings
        </button>
      </div>

      <div style={{ maxWidth: '800px' }}>
        {activeTab === 'profile' ? (
          <div className="fade-in">
            <div className="card" style={{ marginBottom: '1.5rem' }}>
              <h3 style={{ marginBottom: '1.5rem' }}>Basic Information</h3>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
                <div style={{ gridColumn: 'span 2' }}>
                  <label style={labelStyle}>Full Name</label>
                  <input type="text" defaultValue="Dr. Sameer Khan" style={inputStyle} />
                </div>
                <div>
                  <label style={labelStyle}>Email</label>
                  <input type="email" defaultValue="sameer@clinic.com" style={inputStyle} />
                </div>
                <div>
                  <label style={labelStyle}>Mobile</label>
                  <input type="tel" defaultValue="9191919191" style={inputStyle} />
                </div>
                <div style={{ gridColumn: 'span 2' }}>
                  <label style={labelStyle}>Specialization</label>
                  <input type="text" defaultValue="Cardiology & Internal Medicine" style={inputStyle} />
                </div>
              </div>
            </div>

            <div className="card" style={{ marginBottom: '1.5rem' }}>
              <h3 style={{ marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}><Clock size={20} /> Availability</h3>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                <div>
                  <label style={labelStyle}>Available Days</label>
                  <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap', marginTop: '0.5rem' }}>
                    {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
                      <div key={day} style={{ padding: '0.5rem 1rem', borderRadius: '10px', backgroundColor: '#f0fdf4', color: '#10b981', border: '1px solid #bbf7d0', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                        <CheckCircle size={14} /> {day}
                      </div>
                    ))}
                  </div>
                </div>
                <div>
                  <label style={labelStyle}>Consultation Time Slots</label>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                    <input type="time" defaultValue="10:00" style={inputStyle} />
                    <input type="time" defaultValue="18:00" style={inputStyle} />
                  </div>
                </div>
              </div>
            </div>

            <button style={{ width: '100%', backgroundColor: '#7c3aed', color: 'white', padding: '1rem', borderRadius: '14px', fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem' }}>
              <Save size={18} /> Save Profile Changes
            </button>
          </div>
        ) : (
          <div className="fade-in">
            <div className="card" style={{ marginBottom: '1.5rem' }}>
              <h3 style={{ marginBottom: '1.5rem' }}>Change Password</h3>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
                <div><label style={labelStyle}>Current Password</label><input type="password" style={inputStyle} /></div>
                <div><label style={labelStyle}>New Password</label><input type="password" style={inputStyle} /></div>
                <div><label style={labelStyle}>Confirm New Password</label><input type="password" style={inputStyle} /></div>
                <button style={{ backgroundColor: '#7c3aed', color: 'white', padding: '0.8rem', borderRadius: '12px', fontWeight: 700 }}>Update Password</button>
              </div>
            </div>

            <div className="card" style={{ border: '1px solid #fee2e2' }}>
              <h3 style={{ color: '#ef4444', marginBottom: '1rem' }}>Danger Zone</h3>
              <p style={{ color: '#64748b', fontSize: '0.9rem', marginBottom: '1.5rem' }}>Logging out from all devices will end your current session everywhere except this device.</p>
              <button style={{ backgroundColor: '#fef2f2', color: '#ef4444', border: '1px solid #fee2e2', padding: '0.8rem 1.5rem', borderRadius: '12px', fontWeight: 600, display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <LogOut size={18} /> Logout from all devices
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Settings;
