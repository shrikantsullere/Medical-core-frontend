import React, { useState } from 'react';
import { SectionHeader } from '../../components/DashboardElements';
import { MOCK_PAYMENTS } from '../../data/mockData';
import { FileText, Download, Eye, CreditCard, Calendar, Building, CheckCircle } from 'lucide-react';
import Drawer from '../../components/Drawer.jsx';
import jsPDF from 'jspdf';

const Payments = () => {
  const [selectedPay, setSelectedPay] = useState(null);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  const handleViewDetails = (pay) => {
    setSelectedPay(pay);
    setIsDrawerOpen(true);
  };

  const handleDownloadInvoice = (pay) => {
    const doc = new jsPDF();

    // Brand / Title
    doc.setFontSize(24);
    doc.setTextColor(33, 33, 33);
    doc.text("Payment Receipt", 105, 20, { align: "center" });

    // Divider
    doc.setDrawColor(200, 200, 200);
    doc.setLineWidth(0.5);
    doc.line(20, 25, 190, 25);

    // Date Info
    doc.setFontSize(10);
    doc.setTextColor(100, 100, 100);
    doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 190, 35, { align: "right" });

    // Payment Info Section
    doc.setFontSize(12);
    doc.setTextColor(50, 50, 50);

    // Left Column
    doc.setFont("helvetica", "bold");
    doc.text("Payer Details:", 20, 50);
    doc.setFont("helvetica", "normal");
    doc.text(pay.clinic, 20, 60);

    // Right Column
    doc.setFont("helvetica", "bold");
    doc.text("Payment Information:", 120, 50);
    doc.setFont("helvetica", "normal");
    doc.text(`Transaction ID: ${pay.txId}`, 120, 60);
    doc.text(`Date: ${pay.date}`, 120, 68);
    doc.text(`Method: ${pay.mode}`, 120, 76);
    doc.text(`Status: ${pay.status}`, 120, 84);

    // Amount Box
    doc.setFillColor(240, 253, 244); // Light green bg
    doc.setDrawColor(220, 252, 231);
    doc.rect(20, 100, 170, 50, 'FD'); // Fill and Draw

    doc.setFontSize(14);
    doc.setTextColor(21, 128, 61); // Green text
    doc.text("Total Paid Amount", 105, 115, { align: "center" });

    doc.setFontSize(30);
    doc.setFont("helvetica", "bold");
    doc.text(pay.amount, 105, 135, { align: "center" });

    // Footer
    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(150, 150, 150);
    doc.text("Thank you for your business.", 105, 180, { align: "center" });
    doc.text("Clinical Management System", 105, 186, { align: "center" });

    // Save
    doc.save(`Receipt_${pay.txId}.pdf`);
  };

  const labelStyle = {
    display: 'block',
    fontSize: '0.75rem',
    fontWeight: 700,
    color: '#94a3b8',
    textTransform: 'uppercase',
    marginBottom: '0.25rem'
  };

  return (
    <div className="fade-in">
      <SectionHeader title="System Payments" desc="View and track all subscription payments across the system." />

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>Transaction ID</th>
              <th>Clinic Name</th>
              <th>Amount</th>
              <th>Mode</th>
              <th>Status</th>
              <th>Date</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {MOCK_PAYMENTS.map(pay => (
              <tr key={pay.id}>
                <td data-label="Transaction ID"><span style={{ fontWeight: 600, color: '#64748b' }}>{pay.txId}</span></td>
                <td data-label="Clinic Name"><b>{pay.clinic}</b></td>
                <td data-label="Amount" style={{ fontWeight: 700, color: 'var(--primary)' }}>{pay.amount}</td>
                <td data-label="Mode">{pay.mode}</td>
                <td data-label="Status">
                  <span className={`badge ${pay.status === 'Success' ? 'badge-success' : 'badge-warning'}`}>
                    {pay.status}
                  </span>
                </td>
                <td data-label="Date">{pay.date}</td>
                <td data-label="Action">
                  <div style={{ display: 'flex', gap: '0.5rem' }}>
                    <button className="action-btn" title="View Transaction" onClick={() => handleViewDetails(pay)}><Eye size={18} color="var(--primary)" /></button>
                    <button className="action-btn" title="Download Invoice" onClick={() => handleDownloadInvoice(pay)}><Download size={18} color="var(--secondary)" /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Drawer isOpen={isDrawerOpen} onClose={() => setIsDrawerOpen(false)} title="Payment Transaction Details">
        {selectedPay && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
            <div style={{ textAlign: 'center', backgroundColor: '#f0fdf4', padding: '2rem', borderRadius: '24px', border: '1px solid #dcfce7' }}>
              <CheckCircle size={48} color="#10b981" style={{ marginBottom: '1rem' }} />
              <h2 style={{ fontSize: '2rem', color: '#166534' }}>{selectedPay.amount}</h2>
              <p style={{ fontWeight: 700, color: '#15803d', marginTop: '0.5rem' }}>Payment Successful</p>
              <p style={{ fontSize: '0.85rem', color: '#15803d', opacity: 0.8 }}>TXN ID: {selectedPay.txId}</p>
            </div>

            <div className="card" style={{ background: 'white', display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
              <div style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
                <div style={{ padding: '0.75rem', borderRadius: '12px', background: 'var(--bg-main)' }}><Building size={20} color="var(--primary)" /></div>
                <div>
                  <label style={labelStyle}>Payer Clinic</label>
                  <p style={{ fontWeight: 700 }}>{selectedPay.clinic}</p>
                </div>
              </div>
              <div style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
                <div style={{ padding: '0.75rem', borderRadius: '12px', background: 'var(--bg-main)' }}><CreditCard size={20} color="var(--primary)" /></div>
                <div>
                  <label style={labelStyle}>Payment Method</label>
                  <p style={{ fontWeight: 700 }}>{selectedPay.mode}</p>
                </div>
              </div>
              <div style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
                <div style={{ padding: '0.75rem', borderRadius: '12px', background: 'var(--bg-main)' }}><Calendar size={20} color="var(--primary)" /></div>
                <div>
                  <label style={labelStyle}>Transaction Date</label>
                  <p style={{ fontWeight: 700 }}>{selectedPay.date}</p>
                </div>
              </div>
            </div>

            <div style={{ padding: '1.25rem', borderRadius: '16px', border: '1px solid var(--border)', background: '#f8fafc' }}>
              <h4 style={{ marginBottom: '0.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}><FileText size={18} /> Note</h4>
              <p style={{ fontSize: '0.9rem', color: 'var(--text-muted)' }}>This payment was received via Stripe integration. Settlement will be processed within 2-3 business days.</p>
            </div>

            <button className="btn-primary" style={{ width: '100%', padding: '1rem', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.75rem' }} onClick={() => handleDownloadInvoice(selectedPay)}>
              <Download size={20} /> Download PDF Invoice
            </button>
          </div>
        )}
      </Drawer>
    </div>
  );
};

export default Payments;
