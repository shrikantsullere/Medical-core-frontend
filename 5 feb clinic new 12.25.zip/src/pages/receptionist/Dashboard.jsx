import React from 'react';
import { Calendar, Users, Wallet, CheckCircle, UserPlus, Clock, CreditCard } from 'lucide-react';
import { StatCard, SectionHeader } from '../../components/DashboardElements';

const Dashboard = () => {
  const quickActions = [
    { label: 'Add Patient', icon: UserPlus, color: '#7c3aed', bg: '#f5f3ff' },
    { label: 'Book Appointment', icon: Calendar, color: '#0ea5e9', bg: '#f0f9ff' },
    { label: 'Collect Payment', icon: CreditCard, color: '#10b981', bg: '#f0fdf4' },
  ];

  return (
    <div className="fade-in">
      <SectionHeader title="Reception Dashboard" desc="Welcome back! Here's the front-desk summary for today." />

      {/* UI CARDS */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1.25rem', marginBottom: '2rem' }}>
        <StatCard title="Today Appointments" value="32" color="#3b82f6" icon={Calendar} />
        <StatCard title="Walk-in Patients" value="12" color="#8b5cf6" icon={UserPlus} />
        <StatCard title="Pending Payments" value="$ 12,400" color="#ef4444" icon={Wallet} />
        <StatCard title="Total Check-ins" value="28" color="#10b981" icon={CheckCircle} />
      </div>

      {/* QUICK ACTIONS */}


      <div className="card">
        <h3 style={{ marginBottom: '1.5rem' }}>Today's Arriving Patients</h3>
        <div className="table-container" style={{ border: 'none', boxShadow: 'none' }}>
          <table>
            <thead>
              <tr>
                <th>Patient</th>
                <th>Doctor</th>
                <th>Time</th>
                <th>Type</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><b>Deepak Verma</b></td>
                <td>Dr. Sameer Khan</td>
                <td>10:30 AM</td>
                <td><span className="badge badge-blue">New Visit</span></td>
                <td><span className="badge badge-warning">Pending</span></td>
              </tr>
              <tr>
                <td><b>Sneha Patel</b></td>
                <td>Dr. Anjali Rao</td>
                <td>11:45 AM</td>
                <td><span className="badge badge-blue">Follow-up</span></td>
                <td><span className="badge badge-success">Completed</span></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
