import React, { useState } from 'react';
import { Eye, KeyRound, Ban, LogOut, CheckCircle, Search, Filter, Shield, Mail, Calendar, User } from 'lucide-react';
import { SectionHeader } from '../../components/DashboardElements';
import { MOCK_USERS } from '../../data/mockData';
import Drawer from '../../components/Drawer.jsx';

const Users = () => {
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);

  const handleViewUser = (user) => {
    setSelectedUser(user);
    setIsDrawerOpen(true);
  };

  return (
    <div className="fade-in">
      <SectionHeader title="System Users" desc="Manage all clinic administrators and system users." />

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Clinic Name</th>
              <th>Last Login</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {MOCK_USERS.map(u => (
              <tr key={u.id}>
                <td data-label="Name"><b>{u.name}</b></td>
                <td data-label="Email">{u.email}</td>
                <td data-label="Clinic Name">{u.clinic}</td>
                <td data-label="Last Login"><span style={{ fontSize: '0.85rem', color: '#64748b' }}>{u.lastLogin}</span></td>
                <td data-label="Status">
                  <span className={`badge ${u.status === 'Active' ? 'badge-success' : 'badge-danger'}`}>
                    {u.status}
                  </span>
                </td>
                <td data-label="Actions">
                  <div style={{ display: 'flex', gap: '0.5rem' }}>
                    <button className="action-btn" title="View Details" onClick={() => handleViewUser(u)}><Eye size={18} color="var(--primary)" /></button>

                    <button className="action-btn" title={u.status === 'Active' ? 'Block' : 'Unblock'} onClick={() => confirm(`Are you sure you want to ${u.status === 'Active' ? 'block' : 'unblock'} this user?`) && alert('User status updated')}>
                      {u.status === 'Active' ? <Ban size={18} color="var(--danger)" /> : <CheckCircle size={18} color="#10b981" />}
                    </button>

                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Drawer isOpen={isDrawerOpen} onClose={() => setIsDrawerOpen(false)} title="User Details">
        {selectedUser && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
            <div style={{ textAlign: 'center', padding: '1rem' }}>
              <div style={{ width: '80px', height: '80px', borderRadius: '50%', backgroundColor: 'var(--bg-header)', color: 'var(--primary)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '2rem', fontWeight: 800, margin: '0 auto 1rem' }}>
                {selectedUser.name.charAt(0)}
              </div>
              <h3>{selectedUser.name}</h3>
              <p style={{ color: 'var(--text-muted)' }}>{selectedUser.email}</p>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.25rem' }}>
              <div className="card" style={{ padding: '1rem', background: 'var(--bg-main)' }}>
                <label style={{ fontSize: '0.7rem', fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase' }}>Associated Clinic</label>
                <p style={{ fontWeight: 600, marginTop: '0.25rem', color: 'var(--heading)' }}>{selectedUser.clinic}</p>
              </div>
              <div className="card" style={{ padding: '1rem', background: 'var(--bg-main)' }}>
                <label style={{ fontSize: '0.7rem', fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase' }}>Account Status</label>
                <p style={{ fontWeight: 600, marginTop: '0.25rem', color: 'var(--heading)' }}>{selectedUser.status}</p>
              </div>
              <div className="card" style={{ padding: '1rem', background: 'var(--bg-main)' }}>
                <label style={{ fontSize: '0.7rem', fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase' }}>Last Login</label>
                <p style={{ fontWeight: 600, marginTop: '0.25rem', color: 'var(--heading)' }}>{selectedUser.lastLogin}</p>
              </div>
              <div className="card" style={{ padding: '1rem', background: 'var(--bg-main)' }}>
                <label style={{ fontSize: '0.7rem', fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase' }}>Role</label>
                <p style={{ fontWeight: 600, marginTop: '0.25rem', color: 'var(--heading)' }}>Clinic Administrator</p>
              </div>
            </div>

            <div style={{ display: 'flex', gap: '1rem' }}>
              <button className="btn-primary" style={{ flex: 1, backgroundColor: 'var(--primary)', color: 'white', padding: '0.8rem', borderRadius: '12px', fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem', border: 'none' }}>
                <KeyRound size={18} /> Reset Password
              </button>
              <button style={{ flex: 1, backgroundColor: 'rgba(239, 68, 68, 0.1)', color: 'var(--danger)', padding: '0.8rem', borderRadius: '12px', fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem', border: '1px solid var(--danger)' }}>
                <Ban size={18} /> Block User
              </button>
            </div>
          </div>
        )}
      </Drawer>
    </div>
  );
};

export default Users;
