import React from 'react';
import { StatCard, SectionHeader } from '../../components/DashboardElements';
import { Calendar, History, Wallet, ClipboardList, Plus, CreditCard, Eye } from 'lucide-react';

const Dashboard = () => {
  const quickActions = [
    { label: 'Book Appointment', icon: Plus, color: '#0ea5e9', bg: '#f0f9ff' },
    { label: 'Pay Bill', icon: CreditCard, color: '#10b981', bg: '#f0fdf4' },
    { label: 'View Prescription', icon: ClipboardList, color: '#7c3aed', bg: '#f5f3ff' },
  ];

  return (
    <div className="fade-in">
      <SectionHeader title="Welcome back, Deepak!" desc="Manage your health records and upcoming clinic visits." />

      {/* UI CARDS */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1.25rem', marginBottom: '2rem' }}>
        <StatCard title="Upcoming Appointment" value="25 March" color="#3b82f6" icon={Calendar} />
        <StatCard title="Total Visits" value="12" color="#8b5cf6" icon={History} />
        <StatCard title="Pending Bills" value="$ 500" color="#ef4444" icon={Wallet} />
        <StatCard title="Last Prescription" value="20 March" color="#10b981" icon={ClipboardList} />
      </div>

      {/* QUICK ACTIONS */}


      <div className="card">
        <h3 style={{ marginBottom: '1.5rem' }}>Upcoming Appointment Details</h3>
        <div style={{ padding: '1.5rem', backgroundColor: '#f8fafc', borderRadius: '16px', border: '1px solid #e2e8f0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ display: 'flex', gap: '1.5rem', alignItems: 'center' }}>
            <div style={{ width: '60px', height: '60px', borderRadius: '15px', backgroundColor: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', border: '1px solid #e2e8f0' }}>
              <Calendar color="#3b82f6" size={30} />
            </div>
            <div>
              <h4 style={{ fontSize: '1.1rem', marginBottom: '0.25rem' }}>Dr. Sameer Khan</h4>
              <p style={{ color: '#64748b', fontSize: '0.9rem' }}>City Dental Clinic • 10:30 AM • 25 March 2024</p>
            </div>
          </div>
          <button style={{ padding: '0.75rem 1.5rem', borderRadius: '12px', backgroundColor: 'white', border: '1px solid #e2e8f0', fontWeight: 600, color: '#475569' }}>View Details</button>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
