import React, { useState } from 'react';
import { FileText, Printer, Edit, Eye, Download, Plus, Trash2, Save, User, Activity } from 'lucide-react';
import { SectionHeader } from '../../components/DashboardElements';
import { MOCK_PRESCRIPTIONS, MOCK_PATIENTS } from '../../data/mockData';
import Drawer from '../../components/Drawer.jsx';

const Prescriptions = () => {
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [viewMode, setViewMode] = useState('list'); // list or form
  const [medicines, setMedicines] = useState([{ name: '', dosage: '', frequency: '', duration: '' }]);

  const addMedicine = () => {
    setMedicines([...medicines, { name: '', dosage: '', frequency: '', duration: '' }]);
  };

  const removeMedicine = (index) => {
    setMedicines(medicines.filter((_, i) => i !== index));
  };

  const handleCreateNew = () => {
    setMedicines([{ name: '', dosage: '', frequency: '', duration: '' }]);
    setViewMode('form');
    setIsDrawerOpen(true);
  };

  const labelStyle = {
    display: 'block',
    fontSize: '0.75rem',
    fontWeight: 700,
    color: '#94a3b8',
    textTransform: 'uppercase',
    marginBottom: '0.3rem'
  };

  const inputStyle = {
    width: '100%',
    padding: '0.75rem',
    borderRadius: '10px',
    border: '1px solid #e2e8f0',
    fontSize: '0.9rem',
    outline: 'none',
  };

  return (
    <div className="fade-in">
      <SectionHeader
        title="Prescriptions"
        desc="Digital records of patient medications and advice."
        actionLabel="Create Prescription"
        onAction={handleCreateNew}
      />

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>RX ID</th>
              <th>Patient Name</th>
              <th>Date</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {MOCK_PRESCRIPTIONS.map(rx => (
              <tr key={rx.id}>
                <td><span style={{ fontWeight: 600, color: '#64748b' }}>{rx.rxId}</span></td>
                <td><b>{rx.patient}</b></td>
                <td>{rx.date}</td>
                <td><span className="badge badge-success">{rx.status}</span></td>
                <td>
                  <div style={{ display: 'flex', gap: '0.5rem' }}>
                    <button className="action-btn" title="View"><Eye size={18} color="#6366f1" /></button>
                    <button className="action-btn" title="Edit (Same Day Only)"><Edit size={18} color="#f59e0b" /></button>
                    <button className="action-btn" title="Print / Download"><Download size={18} color="#10b981" /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Drawer isOpen={isDrawerOpen} onClose={() => setIsDrawerOpen(false)} title="Create New Prescription">
        <form style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          {/* Patient Details (Shared Context Mock) */}
          <div style={{ backgroundColor: '#f8fafc', padding: '1rem', borderRadius: '12px', border: '1px solid #e2e8f0' }}>
            <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr', gap: '1rem' }}>
              <div>
                <label style={labelStyle}>Patient Name</label>
                <select style={inputStyle}>
                  <option>Select Patient</option>
                  {MOCK_PATIENTS.map(p => <option key={p.id}>{p.name}</option>)}
                </select>
              </div>
              <div><label style={labelStyle}>Age</label><input type="text" defaultValue="34" style={inputStyle} readOnly /></div>
              <div><label style={labelStyle}>Gender</label><input type="text" defaultValue="Male" style={inputStyle} readOnly /></div>
            </div>
          </div>

          {/* Diagnosis */}
          <div>
            <h4 style={{ fontSize: '0.9rem', marginBottom: '1rem', color: '#1e293b', display: 'flex', alignItems: 'center', gap: '0.5rem' }}><Activity size={18} /> Diagnosis & Notes</h4>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              <div>
                <label style={labelStyle}>Symptoms</label>
                <textarea placeholder="e.g. Fever, Cough, Chest Pain" style={{ ...inputStyle, height: '60px' }} />
              </div>
              <div>
                <label style={labelStyle}>Diagnosis Notes</label>
                <textarea placeholder="Observation and clinical notes" style={{ ...inputStyle, height: '60px' }} />
              </div>
            </div>
          </div>

          {/* Medicines (Repeater) */}
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
              <h4 style={{ fontSize: '0.9rem', color: '#1e293b' }}>Medicines</h4>
              <button type="button" onClick={addMedicine} style={{ color: '#7c3aed', fontSize: '0.75rem', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                <Plus size={14} /> Add Medicine
              </button>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              {medicines.map((med, index) => (
                <div key={index} style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 1fr 0.4fr', gap: '0.5rem', alignItems: 'center', padding: '0.75rem', border: '1px solid #f1f5f9', borderRadius: '10px' }}>
                  <input placeholder="Medicine Name" style={{ ...inputStyle, padding: '0.5rem' }} />
                  <input placeholder="Dosage" style={{ ...inputStyle, padding: '0.5rem' }} />
                  <input placeholder="Freq" style={{ ...inputStyle, padding: '0.5rem' }} />
                  <input placeholder="Dur" style={{ ...inputStyle, padding: '0.5rem' }} />
                  {index > 0 && <button type="button" onClick={() => removeMedicine(index)} style={{ color: '#ef4444' }}><Trash2 size={18} /></button>}
                </div>
              ))}
            </div>
          </div>

          {/* Advice */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
            <div style={{ gridColumn: 'span 2' }}>
              <label style={labelStyle}>General Instructions / Advice</label>
              <textarea placeholder="e.g. Bed rest for 2 days, Drink warm water" style={{ ...inputStyle, height: '60px' }} />
            </div>
            <div>
              <label style={labelStyle}>Follow-up Date</label>
              <input type="date" style={inputStyle} />
            </div>
          </div>

          {/* Buttons */}
          <div style={{ display: 'flex', gap: '1rem', marginTop: '1rem' }}>
            <button className="btn-primary" style={{ flex: 1, backgroundColor: '#7c3aed', color: 'white', padding: '1rem', borderRadius: '14px', fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem' }}>
              <Save size={20} /> Save Prescription
            </button>
            <button className="btn-secondary" style={{ flex: 1, backgroundColor: '#f0fdf4', color: '#10b981', padding: '1rem', borderRadius: '14px', fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem' }}>
              <Printer size={20} /> Save & Print
            </button>
          </div>
        </form>
      </Drawer>
    </div>
  );
};

export default Prescriptions;
