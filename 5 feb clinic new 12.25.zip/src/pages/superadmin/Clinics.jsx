import React, { useState } from 'react';
import { Eye, Edit, Trash2, LogIn, RefreshCcw, Ban, CheckCircle, Plus, Upload, Mail, Phone, MapPin, Shield, Calendar, UserCog, Landmark, Search } from 'lucide-react';
import { SectionHeader } from '../../components/DashboardElements';
import { MOCK_CLINICS, MOCK_PLANS } from '../../data/mockData';
import Drawer from '../../components/Drawer.jsx';

const Clinics = () => {
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [selectedClinic, setSelectedClinic] = useState(null);
  const [viewType, setViewType] = useState('list'); // list, add
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');

  const inputStyle = {
    width: '100%',
    padding: '0.75rem',
    borderRadius: '10px',
    border: '1px solid #e2e8f0',
    fontSize: '0.9rem',
    outline: 'none',
    transition: 'all 0.2s',
  };

  const labelStyle = {
    display: 'block',
    fontSize: '0.8rem',
    fontWeight: 700,
    color: 'var(--text-muted)',
    marginBottom: '0.5rem',
    textTransform: 'uppercase',
    letterSpacing: '0.025em'
  };

  const formSectionStyle = {
    marginBottom: '2rem',
    padding: '1.5rem',
    backgroundColor: 'var(--bg-main)',
    borderRadius: '16px',
    border: '1px solid var(--border)'
  };

  const filteredClinics = MOCK_CLINICS.filter(clinic => {
    const matchesSearch = clinic.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      clinic.admin.toLowerCase().includes(searchTerm.toLowerCase()) ||
      clinic.clinicId.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'All' || clinic.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleAddClinic = () => {
    setViewType('add');
    setIsDrawerOpen(true);
  };

  return (
    <div className="fade-in">
      <SectionHeader
        title="Clinics Management"
        desc="Oversee all clinics, manage subscriptions, and control access."
        actionLabel="Add Clinic"
        onAction={handleAddClinic}
      />

      <div className="card" style={{ marginBottom: '1.5rem', padding: '1rem' }}>
        <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
          <div style={{ flex: 1, minWidth: '250px', position: 'relative' }}>
            <Search size={18} color="#94a3b8" style={{ position: 'absolute', left: '1rem', top: '50%', transform: 'translateY(-50%)' }} />
            <input
              type="text"
              placeholder="Search by clinic name, ID or admin..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              style={{ width: '100%', padding: '0.75rem 1rem 0.75rem 2.8rem', borderRadius: '10px', border: '1px solid #e2e8f0', outline: 'none', backgroundColor: 'var(--bg-sidebar)', color: 'var(--text-main)' }}
            />
          </div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            style={{ padding: '0 1rem', borderRadius: '10px', border: '1px solid #e2e8f0', backgroundColor: 'var(--bg-sidebar)', color: 'var(--text-main)', outline: 'none' }}
          >
            <option value="All">All Status</option>
            <option value="Active">Active</option>
            <option value="Inactive">Inactive</option>
          </select>
        </div>
      </div>

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>Clinic ID</th>
              <th>Clinic Name</th>
              <th>Admin Name</th>
              <th>Contact</th>
              <th>Plan</th>
              <th>Expiry</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {filteredClinics.map(clinic => (
              <tr key={clinic.id}>
                <td data-label="Clinic ID"><span style={{ fontWeight: 600, color: '#64748b' }}>{clinic.clinicId}</span></td>
                <td data-label="Clinic Name"><b>{clinic.name}</b></td>
                <td data-label="Admin Name">{clinic.admin}</td>
                <td data-label="Contact">
                  <div style={{ fontSize: '0.85rem' }}>{clinic.email}</div>
                  <div style={{ fontSize: '0.75rem', color: '#64748b' }}>{clinic.mobile}</div>
                </td>
                <td data-label="Plan"><span className="badge badge-blue">{clinic.plan}</span></td>
                <td data-label="Expiry">{clinic.expiry}</td>
                <td data-label="Status">
                  <span className={`badge ${clinic.status === 'Active' ? 'badge-success' : 'badge-danger'}`}>
                    {clinic.status}
                  </span>
                </td>
                <td data-label="Action">
                  <div style={{ display: 'flex', gap: '0.4rem' }}>
                    <button className="action-btn" title="View Details" onClick={() => { setViewType('view'); setSelectedClinic(clinic); setIsDrawerOpen(true); }}><Eye size={16} color="var(--primary)" /></button>
                    <button className="action-btn" title="Edit" onClick={() => { setViewType('edit'); setSelectedClinic(clinic); setIsDrawerOpen(true); }}><Edit size={16} color="var(--secondary)" /></button>

                    <button className="action-btn" title="Delete" onClick={() => confirm('Are you sure you want to delete this clinic? This action cannot be undone.') && alert('Clinic deleted successfully.')}><Trash2 size={16} color="var(--danger)" /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Drawer
        isOpen={isDrawerOpen}
        onClose={() => setIsDrawerOpen(false)}
        title={viewType === 'add' ? "Registration - New Clinic" : viewType === 'view' ? "Clinic Details (View Mode)" : "Edit Clinic Information"}
      >
        <form style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          {/* A. Clinic Details */}
          <div style={formSectionStyle}>
            <h4 style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '1.25rem', color: 'var(--heading)' }}>
              <Landmark size={18} /> A. Clinic Details
            </h4>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <div style={{ gridColumn: 'span 2' }}>
                <label style={labelStyle}>Clinic Name *</label>
                <input type="text" defaultValue={selectedClinic?.name || ''} placeholder="Enter full clinic name" style={inputStyle} required readOnly={viewType === 'view'} />
              </div>
              <div style={{ gridColumn: 'span 2' }}>
                <label style={labelStyle}>Clinic Logo</label>
                <div style={{ border: '2px dashed #e2e8f0', borderRadius: '12px', padding: '1rem', textAlign: 'center', color: '#94a3b8', cursor: 'pointer' }}>
                  <Upload size={24} style={{ marginBottom: '0.5rem' }} />
                  <p style={{ fontSize: '0.75rem' }}>Click to upload or drag logo</p>
                </div>
              </div>
              <div>
                <label style={labelStyle}>Clinic Email</label>
                <input type="email" placeholder="clinic@email.com" style={inputStyle} />
              </div>
              <div>
                <label style={labelStyle}>Clinic Phone</label>
                <input type="tel" placeholder="+91 00000 00000" style={inputStyle} />
              </div>
              <div style={{ gridColumn: 'span 2' }}>
                <label style={labelStyle}>Full Address</label>
                <textarea placeholder="Line 1, Line 2..." style={{ ...inputStyle, minHeight: '80px', resize: 'vertical' }} />
              </div>
              <div>
                <label style={labelStyle}>City</label>
                <input type="text" placeholder="Mumbai" style={inputStyle} />
              </div>
              <div>
                <label style={labelStyle}>State</label>
                <input type="text" placeholder="Maharashtra" style={inputStyle} />
              </div>
            </div>
          </div>

          {/* B. Admin Account */}
          <div style={formSectionStyle}>
            <h4 style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '1.25rem', color: 'var(--heading)' }}>
              <UserCog size={18} /> B. Admin Account
            </h4>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <div style={{ gridColumn: 'span 2' }}>
                <label style={labelStyle}>Admin Name *</label>
                <input type="text" defaultValue={selectedClinic?.admin || ''} placeholder="Primary administrator name" style={inputStyle} required readOnly={viewType === 'view'} />
              </div>
              <div>
                <label style={labelStyle}>Admin Email *</label>
                <input type="email" defaultValue={selectedClinic?.email || ''} placeholder="admin@clinic.com" style={inputStyle} required readOnly={viewType === 'view'} />
              </div>
              <div>
                <label style={labelStyle}>Admin Password *</label>
                <input type="password" placeholder="Create Password" style={inputStyle} required={viewType === 'add'} readOnly={viewType === 'view'} />
              </div>
              <div>
                <label style={labelStyle}>Admin Mobile</label>
                <input type="tel" placeholder="+91 99999 99999" style={inputStyle} />
              </div>
              <div style={{ gridColumn: 'span 2', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <input type="checkbox" id="sendEmail" style={{ width: '16px', height: '16px' }} defaultChecked />
                <label htmlFor="sendEmail" style={{ fontSize: '0.85rem', color: '#64748b', cursor: 'pointer' }}>Send login details on email</label>
              </div>
            </div>
          </div>

          {/* C. Subscription */}
          <div style={formSectionStyle}>
            <h4 style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '1.25rem', color: 'var(--heading)' }}>
              <Shield size={18} /> C. Subscription
            </h4>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <div style={{ gridColumn: 'span 2' }}>
                <label style={labelStyle}>Select Plan</label>
                <select style={inputStyle}>
                  {MOCK_PLANS.map(p => <option key={p.id}>{p.name} ({p.price})</option>)}
                </select>
              </div>
              <div>
                <label style={labelStyle}>Start Date</label>
                <input type="date" style={inputStyle} />
              </div>
              <div>
                <label style={labelStyle}>Expiry Date</label>
                <input type="date" style={inputStyle} disabled />
              </div>
            </div>
          </div>

          {/* Buttons */}
          <div style={{ display: 'flex', gap: '1rem', marginTop: '1rem' }}>
            <button type="submit" style={{ flex: 1, backgroundColor: '#7c3aed', color: 'white', padding: '1rem', borderRadius: '12px', fontWeight: 700, border: 'none' }}>Save & Activate</button>
            <button type="button" style={{ backgroundColor: '#f1f5f9', color: '#64748b', padding: '1rem 1.5rem', borderRadius: '12px', fontWeight: 600, border: 'none' }}>Save Draft</button>
            <button type="button" onClick={() => setIsDrawerOpen(false)} style={{ backgroundColor: 'white', color: '#ef4444', padding: '1rem 1.5rem', borderRadius: '12px', fontWeight: 600, border: '1px solid #fee2e2' }}>Cancel</button>
          </div>
        </form>
      </Drawer>
    </div>
  );
};

export default Clinics;
