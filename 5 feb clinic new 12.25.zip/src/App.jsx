import React, { lazy, Suspense } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ThemeProvider } from './context/ThemeContext';
import { ROLES } from './data/mockData';
import Layout from './components/Layout';
import LoginPage from './pages/LoginPage';
import PublicInvoice from './pages/PublicInvoice';

// Super Admin Pages
const SADashboard = lazy(() => import('./pages/superadmin/Dashboard'));
const SAClinics = lazy(() => import('./pages/superadmin/Clinics'));
const SAPlans = lazy(() => import('./pages/superadmin/Plans'));
const SAUsers = lazy(() => import('./pages/superadmin/Users'));
const SASettings = lazy(() => import('./pages/superadmin/Settings'));
const SAReports = lazy(() => import('./pages/superadmin/Reports'));
const SALogs = lazy(() => import('./pages/superadmin/AuditLogs'));
const SAPayments = lazy(() => import('./pages/superadmin/Payments'));

// Clinic Admin Pages
const CADashboard = lazy(() => import('./pages/clinicadmin/Dashboard'));
const CAPatients = lazy(() => import('./pages/clinicadmin/Patients'));
const CADoctors = lazy(() => import('./pages/clinicadmin/Doctors'));
const CAAppointments = lazy(() => import('./pages/clinicadmin/Appointments'));
const CAServices = lazy(() => import('./pages/clinicadmin/Services'));
const CABilling = lazy(() => import('./pages/clinicadmin/Billing'));
const CAPayments = lazy(() => import('./pages/clinicadmin/Payments'));
const CAStaff = lazy(() => import('./pages/clinicadmin/Staff'));
const CAReports = lazy(() => import('./pages/clinicadmin/Reports'));
const CASettings = lazy(() => import('./pages/clinicadmin/Settings'));

// Doctor Pages
const DRDashboard = lazy(() => import('./pages/doctor/Dashboard'));
const DRAppointments = lazy(() => import('./pages/doctor/Appointments'));
const DRPatients = lazy(() => import('./pages/doctor/Patients'));
const DRPrescription = lazy(() => import('./pages/doctor/Prescriptions'));
const DREarnings = lazy(() => import('./pages/doctor/Earnings'));
const DRSettings = lazy(() => import('./pages/doctor/Settings'));

// Receptionist Pages
const RCDashboard = lazy(() => import('./pages/receptionist/Dashboard'));
const RCPatients = lazy(() => import('./pages/receptionist/Patients'));
const RCAppointments = lazy(() => import('./pages/receptionist/Appointments'));
const RCBilling = lazy(() => import('./pages/receptionist/Billing'));
const RCPayments = lazy(() => import('./pages/receptionist/Payments'));
const RCProfile = lazy(() => import('./pages/receptionist/Profile'));

// Accountant Pages
const ACDashboard = lazy(() => import('./pages/accountant/Dashboard'));
const ACInvoices = lazy(() => import('./pages/accountant/Invoices'));
const ACPayments = lazy(() => import('./pages/accountant/Payments'));
const ACExpenses = lazy(() => import('./pages/accountant/Expenses'));
const ACPayouts = lazy(() => import('./pages/accountant/DoctorPayouts'));
const ACReports = lazy(() => import('./pages/accountant/Reports'));
const ACProfile = lazy(() => import('./pages/accountant/Profile'));

// Patient Pages
const PTDashboard = lazy(() => import('./pages/patient/Dashboard'));
const PTAppointments = lazy(() => import('./pages/patient/Appointments'));
const PTBilling = lazy(() => import('./pages/patient/Billing'));
const PTPrescriptions = lazy(() => import('./pages/patient/Prescriptions'));
const PTProfile = lazy(() => import('./pages/patient/Profile'));

const ProtectedRoute = ({ children }) => {
  const { isAuthenticated, loading } = useAuth();
  if (loading) return <div style={{ height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.2rem', fontWeight: 600, color: 'var(--primary)' }}>Loading...</div>;
  return isAuthenticated ? <Layout>{children}</Layout> : <Navigate to="/" />;
};

const RoleRoutes = () => {
  const { user } = useAuth();
  if (!user) return null;

  const rolesRoutes = {
    [ROLES.SUPER_ADMIN]: [
      { path: '/dashboard', element: <SADashboard /> },
      { path: '/clinics', element: <SAClinics /> },
      { path: '/plans', element: <SAPlans /> },
      { path: '/users', element: <SAUsers /> },
      { path: '/payments', element: <SAPayments /> },
      { path: '/settings', element: <SASettings /> },
      { path: '/reports', element: <SAReports /> },
      { path: '/logs', element: <SALogs /> },
    ],
    [ROLES.CLINIC_ADMIN]: [
      { path: '/dashboard', element: <CADashboard /> },
      { path: '/patients', element: <CAPatients /> },
      { path: '/doctors', element: <CADoctors /> },
      { path: '/appointments', element: <CAAppointments /> },
      { path: '/services', element: <CAServices /> },
      { path: '/billing', element: <CABilling /> },
      { path: '/payments', element: <CAPayments /> },
      { path: '/staff', element: <CAStaff /> },
      { path: '/reports', element: <CAReports /> },
      { path: '/settings', element: <CASettings /> },
    ],
    [ROLES.DOCTOR]: [
      { path: '/dashboard', element: <DRDashboard /> },
      { path: '/appointments', element: <DRAppointments /> },
      { path: '/patients', element: <DRPatients /> },
      { path: '/prescriptions', element: <DRPrescription /> },
      { path: '/earnings', element: <DREarnings /> },
      { path: '/settings', element: <DRSettings /> },
    ],
    [ROLES.RECEPTIONIST]: [
      { path: '/dashboard', element: <RCDashboard /> },
      { path: '/patients', element: <RCPatients /> },
      { path: '/appointments', element: <RCAppointments /> },
      { path: '/billing', element: <RCBilling /> },
      { path: '/payments', element: <RCPayments /> },
      { path: '/profile', element: <RCProfile /> },
    ],
    [ROLES.ACCOUNTANT]: [
      { path: '/dashboard', element: <ACDashboard /> },
      { path: '/invoices', element: <ACInvoices /> },
      { path: '/payments', element: <ACPayments /> },
      { path: '/expenses', element: <ACExpenses /> },
      { path: '/payouts', element: <ACPayouts /> },
      { path: '/reports', element: <ACReports /> },
      { path: '/profile', element: <ACProfile /> },
    ],
    [ROLES.PATIENT]: [
      { path: '/dashboard', element: <PTDashboard /> },
      { path: '/appointments', element: <PTAppointments /> },
      { path: '/billing', element: <PTBilling /> },
      { path: '/prescriptions', element: <PTPrescriptions /> },
      { path: '/profile', element: <PTProfile /> },
    ],
  };

  const currentRoutes = rolesRoutes[user.role] || [];

  return (
    <Suspense fallback={<div style={{ padding: '2rem', textAlign: 'center', color: 'var(--primary)', fontWeight: 600 }}>Loading Module...</div>}>
      <Routes>
        {currentRoutes.map((route) => (
          <Route key={route.path} path={route.path} element={route.element} />
        ))}
        <Route path="/" element={<Navigate to="/dashboard" />} />
        <Route path="*" element={<Navigate to="/dashboard" />} />
      </Routes>
    </Suspense>
  );
};

const App = () => {
  return (
    <ThemeProvider>
      <AuthProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<LoginPage />} />
            <Route path="/invoice-public/:id" element={<PublicInvoice />} />
            <Route path="/*" element={<ProtectedRoute><RoleRoutes /></ProtectedRoute>} />
          </Routes>
        </BrowserRouter>
      </AuthProvider>
    </ThemeProvider>
  );
};

export default App;
