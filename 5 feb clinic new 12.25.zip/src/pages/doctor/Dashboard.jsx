import React from 'react';
import { Calendar, Users, DollarSign, ClipboardList, Clock, TrendingUp, UserPlus } from 'lucide-react';
import { StatCard, SectionHeader } from '../../components/DashboardElements';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';

const Dashboard = () => {
  const chartData = [
    { name: 'Mon', appointments: 12, earnings: 4500 },
    { name: 'Tue', appointments: 15, earnings: 5200 },
    { name: 'Wed', appointments: 10, earnings: 3800 },
    { name: 'Thu', appointments: 18, earnings: 6000 },
    { name: 'Fri', appointments: 14, earnings: 4800 },
    { name: 'Sat', appointments: 22, earnings: 8500 },
    { name: 'Sun', appointments: 5, earnings: 2000 },
  ];

  return (
    <div className="fade-in">
      <SectionHeader title="Doctor Dashboard" desc="Good morning, Dr. Sameer. Here is your practice overview for today." />

      {/* UI CARDS */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '1.25rem', marginBottom: '2rem' }}>
        <StatCard title="Today Appointments" value="18" color="#3b82f6" icon={Clock} />
        <StatCard title="Total Patients" value="842" color="var(--primary)" icon={Users} />
        <StatCard title="Today Earnings" value="$ 4,500" color="#10b981" icon={DollarSign} />
        <StatCard title="Monthly Earnings" value="$ 12.5K" color="#0ea5e9" icon={TrendingUp} />
        <StatCard title="Pending RX" value="4" color="var(--danger)" icon={ClipboardList} />
      </div>

      {/* QUICK ACTIONS */}
      <div style={{ marginBottom: '2rem' }}>
        <h3 style={{ marginBottom: '1.25rem', fontSize: '1rem', color: 'var(--heading)' }}>Quick Actions</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem' }}>
          <button style={{ height: '60px', borderRadius: '14px', backgroundColor: '#f0f9ff', color: '#0ea5e9', border: '1px solid #bae6fd', fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.75rem', transition: 'all 0.2s' }}>
            <Calendar size={20} /> Today Appointments
          </button>
          <button style={{ height: '60px', borderRadius: '14px', backgroundColor: '#f5f3ff', color: 'var(--primary)', border: '1px solid #ddd6fe', fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.75rem', transition: 'all 0.2s' }}>
            <ClipboardList size={20} /> Create Prescription
          </button>
        </div>
      </div>

      <div style={{
        display: 'grid',
        gridTemplateColumns: window.innerWidth < 1024 ? '1fr' : '1.5fr 1fr',
        gap: '1.5rem'
      }}>
        {/* Earnings Chart */}
        <div className="card">
          <h3 style={{ marginBottom: '1.5rem' }}>Earnings (Weekly)</h3>
          <div style={{ height: '300px' }}>
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorEarn" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.1} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 12 }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 12 }} />
                <Tooltip contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)' }} />
                <Area type="monotone" dataKey="earnings" stroke="#10b981" fillOpacity={1} fill="url(#colorEarn)" strokeWidth={3} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Appointments Chart */}
        <div className="card">
          <h3 style={{ marginBottom: '1.5rem' }}>Appointments (Week wise)</h3>
          <div style={{ height: '300px' }}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 12 }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 12 }} />
                <Tooltip contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)' }} />
                <Bar dataKey="appointments" fill="#3b82f6" radius={[6, 6, 0, 0]} barSize={20} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
