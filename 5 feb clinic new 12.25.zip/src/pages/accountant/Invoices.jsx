import React, { useState } from 'react';
import { Eye, Download, Send, Search, Filter, Printer, FileText, User, Building } from 'lucide-react';
import { SectionHeader } from '../../components/DashboardElements';
import { MOCK_INVOICES } from '../../data/mockData';
import Drawer from '../../components/Drawer.jsx';

const Invoices = () => {
  const [selectedInv, setSelectedInv] = useState(null);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  const handleViewInvoice = (inv) => {
    setSelectedInv(inv);
    setIsDrawerOpen(true);
  };

  const labelStyle = {
    display: 'block',
    fontSize: '0.75rem',
    fontWeight: 700,
    color: '#94a3b8',
    textTransform: 'uppercase',
    marginBottom: '0.25rem'
  };

  return (
    <div className="fade-in">
      <SectionHeader title="Financial Invoices" desc="Monitor patient billing, due amounts, and collection status." />

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>Invoice No</th>
              <th>Patient</th>
              <th>Doctor</th>
              <th>Date</th>
              <th>Total Amount</th>
              <th>Paid Amount</th>
              <th>Due Amount</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {MOCK_INVOICES.map(inv => (
              <tr key={inv.id}>
                <td><span style={{ fontWeight: 600 }}>{inv.invId}</span></td>
                <td><b>{inv.patient}</b></td>
                <td>{inv.doctor}</td>
                <td>{inv.date}</td>
                <td style={{ fontWeight: 600 }}>{inv.total}</td>
                <td style={{ color: '#10b981', fontWeight: 600 }}>{inv.paid}</td>
                <td style={{ color: inv.due !== '₹ 0' ? '#ef4444' : '#64748b', fontWeight: 700 }}>{inv.due}</td>
                <td>
                  <span className={`badge ${inv.status === 'Paid' ? 'badge-success' : inv.status === 'Partial' ? 'badge-warning' : 'badge-danger'}`}>
                    {inv.status}
                  </span>
                </td>
                <td>
                  <div style={{ display: 'flex', gap: '0.5rem' }}>
                    <button className="action-btn" onClick={() => handleViewInvoice(inv)} title="View Detail"><Eye size={18} color="#6366f1" /></button>
                    <button className="action-btn" title="Download PDF"><Download size={18} color="#10b981" /></button>

                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Drawer isOpen={isDrawerOpen} onClose={() => setIsDrawerOpen(false)} title="Invoice Detail">
        {selectedInv && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
            {/* Header / Meta */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid #f1f5f9', paddingBottom: '1.5rem' }}>
              <div>
                <h3 style={{ fontSize: '1.5rem', marginBottom: '0.25rem' }}>{selectedInv.invId}</h3>
                <p style={{ color: '#64748b' }}>Date: {selectedInv.date}</p>
              </div>
              <span className={`badge ${selectedInv.status === 'Paid' ? 'badge-success' : 'badge-warning'}`} style={{ padding: '0.5rem 1rem' }}>{selectedInv.status}</span>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
              <div className="card" style={{ padding: '1rem', background: 'var(--bg-main)' }}>
                <label style={labelStyle}><Building size={14} style={{ verticalAlign: 'middle', marginRight: '0.25rem' }} /> Clinic Info</label>
                <p style={{ fontWeight: 800, color: 'var(--heading)' }}>City Dental Clinic</p>
                <p style={{ fontSize: '0.85rem', color: 'var(--text-main)' }}>123 Clinic St, Medical Area, New Delhi</p>
              </div>
              <div className="card" style={{ padding: '1rem', background: 'var(--bg-main)' }}>
                <label style={labelStyle}><User size={14} style={{ verticalAlign: 'middle', marginRight: '0.25rem' }} /> Patient Info</label>
                <p style={{ fontWeight: 800, color: 'var(--heading)' }}>{selectedInv.patient}</p>
                <p style={{ fontSize: '0.85rem', color: 'var(--text-main)' }}>+91 98765 43210</p>
              </div>
            </div>

            {/* Breakdown */}
            <div>
              <h4 style={{ marginBottom: '1rem', color: 'var(--heading)' }}>Amount Breakdown</h4>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', padding: '1rem', border: '1px solid var(--border)', borderRadius: '12px', backgroundColor: 'var(--bg-sidebar)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', color: 'var(--text-main)' }}><span>General Consultation</span><span>₹ 500.00</span></div>
                <div style={{ display: 'flex', justifyContent: 'space-between', color: 'var(--text-main)' }}><span>Blood Test (CBC)</span><span>₹ 500.00</span></div>
                <div style={{ display: 'flex', justifyContent: 'space-between', color: 'var(--text-main)' }}><span>Medicines</span><span>₹ 500.00</span></div>
                <hr style={{ border: 'none', borderTop: '1px dashed var(--border)', margin: '0.5rem 0' }} />
                <div style={{ display: 'flex', justifyContent: 'space-between', color: 'var(--text-muted)' }}><span>Discount</span><span>- ₹ 0.00</span></div>
                <div style={{ display: 'flex', justifyContent: 'space-between', color: 'var(--text-muted)' }}><span>Tax (GST 18%)</span><span>₹ 270.00</span></div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '1.1rem', fontWeight: 800, color: 'var(--primary)', marginTop: '0.5rem' }}>
                  <span>Net Amount</span><span>{selectedInv.total}</span>
                </div>
              </div>
            </div>

            <div style={{ display: 'flex', gap: '1rem', marginTop: '1rem' }}>
              <button style={{ flex: 1, backgroundColor: '#7c3aed', color: 'white', padding: '1rem', borderRadius: '12px', fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem' }}>
                <Printer size={18} /> Print Invoice
              </button>
              <button style={{ flex: 1, backgroundColor: '#f1f5f9', color: '#64748b', padding: '1rem', borderRadius: '12px', fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem' }}>
                <Download size={18} /> Download PDF
              </button>
            </div>
          </div>
        )}
      </Drawer>
    </div>
  );
};

export default Invoices;
