import React, { useState } from 'react';
import { Eye, Clock, Calendar, Search, Filter, Plus, Printer, CheckCircle, XCircle, RefreshCw } from 'lucide-react';
import { SectionHeader } from '../../components/DashboardElements';
import { MOCK_APPOINTMENTS, MOCK_PATIENTS, MOCK_DOCTORS } from '../../data/mockData';
import Drawer from '../../components/Drawer.jsx';

const Appointments = () => {
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [selectedAppt, setSelectedAppt] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [doctorFilter, setDoctorFilter] = useState('All Doctors');

  const filteredAppointments = MOCK_APPOINTMENTS.filter(appt => {
    const matchesSearch = appt.patient.toLowerCase().includes(searchTerm.toLowerCase()) ||
      appt.appId.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDoctor = doctorFilter === 'All Doctors' || appt.doctor === doctorFilter;
    return matchesSearch && matchesDoctor;
  });

  const labelStyle = {
    display: 'block',
    fontSize: '0.75rem',
    fontWeight: 700,
    color: 'var(--text-muted)',
    textTransform: 'uppercase',
    marginBottom: '0.3rem'
  };

  const inputStyle = {
    width: '100%',
    padding: '0.75rem',
    borderRadius: '10px',
    border: '1px solid var(--border)',
    fontSize: '0.9rem',
    outline: 'none',
    backgroundColor: 'var(--bg-sidebar)',
    color: 'var(--text-main)'
  };

  return (
    <div className="fade-in">
      <SectionHeader
        title="Appointments"
        desc="Schedule visits and track patient arrivals."
        actionLabel="Book Appointment"
        onAction={() => setIsDrawerOpen(true)}
      />

      <div className="card" style={{ marginBottom: '1.5rem', padding: '1rem', backgroundColor: 'var(--bg-sidebar)' }}>
        <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
          <div style={{ flex: 1, minWidth: '250px', position: 'relative' }}>
            <Search size={18} color="#94a3b8" style={{ position: 'absolute', left: '1rem', top: '50%', transform: 'translateY(-50%)' }} />
            <input
              type="text"
              placeholder="Search by patient name or ID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              style={{ ...inputStyle, paddingLeft: '2.8rem', backgroundColor: 'var(--bg-main)' }}
            />
          </div>
          <select
            value={doctorFilter}
            onChange={(e) => setDoctorFilter(e.target.value)}
            style={{ padding: '0 1rem', borderRadius: '10px', border: '1px solid var(--border)', backgroundColor: 'var(--bg-main)', color: 'var(--text-main)', outline: 'none', height: '44px' }}
          >
            <option>All Doctors</option>
            {MOCK_DOCTORS.map(d => <option key={d.id} value={d.name}>{d.name}</option>)}
          </select>
        </div>
      </div>

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>Appt ID</th>
              <th>Patient</th>
              <th>Doctor</th>
              <th>Date</th>
              <th>Time Slot</th>
              <th>Type</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredAppointments.map(appt => (
              <tr key={appt.id}>
                <td><span style={{ fontWeight: 600, color: 'var(--text-muted)' }}>{appt.appId}</span></td>
                <td><b style={{ color: 'var(--heading)' }}>{appt.patient}</b></td>
                <td style={{ color: 'var(--text-main)' }}>{appt.doctor}</td>
                <td style={{ color: 'var(--text-main)' }}>{appt.date}</td>
                <td style={{ color: 'var(--text-main)' }}>{appt.time}</td>
                <td><span className="badge badge-blue">{appt.type}</span></td>
                <td><span className={`badge ${appt.status === 'Completed' ? 'badge-success' : 'badge-warning'}`}>{appt.status}</span></td>
                <td>
                  <div style={{ display: 'flex', gap: '0.5rem' }}>
                    <button className="action-btn" title="View" style={{ backgroundColor: 'var(--bg-sidebar)' }}><Eye size={16} color="var(--primary)" /></button>

                    <button className="action-btn" title="Mark Arrived" style={{ backgroundColor: 'var(--bg-sidebar)' }}><CheckCircle size={16} color="var(--accent)" /></button>
                    <button className="action-btn" title="Cancel" style={{ backgroundColor: 'var(--bg-sidebar)' }}><XCircle size={16} color="var(--danger)" /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Drawer isOpen={isDrawerOpen} onClose={() => setIsDrawerOpen(false)} title="Book Appointment">
        <form style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          <div>
            <label style={labelStyle}>Patient (Search / Add New)</label>
            <select style={inputStyle}>
              <option>Search Patient...</option>
              {MOCK_PATIENTS.map(p => <option key={p.id}>{p.name} ({p.patientId})</option>)}
            </select>
          </div>
          <div>
            <label style={labelStyle}>Doctor</label>
            <select style={inputStyle}>
              {MOCK_DOCTORS.map(d => <option key={d.id}>{d.name}</option>)}
            </select>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
            <div>
              <label style={labelStyle}>Appointment Date</label>
              <input type="date" style={inputStyle} />
            </div>
            <div>
              <label style={labelStyle}>Time Slot</label>
              <input type="time" style={inputStyle} />
            </div>
          </div>
          <div>
            <label style={labelStyle}>Visit Type</label>
            <select style={inputStyle}>
              <option>New Visit</option>
              <option>Follow-up</option>
            </select>
          </div>
          <div>
            <label style={labelStyle}>Notes</label>
            <textarea placeholder="Reason for appointment..." style={{ ...inputStyle, height: '80px' }} />
          </div>
          <div style={{ display: 'flex', gap: '1rem' }}>
            <button className="btn-primary" style={{ flex: 1, backgroundColor: '#7c3aed', color: 'white', padding: '1rem', borderRadius: '12px', fontWeight: 700 }}>Save Appointment</button>
            <button className="btn-secondary" style={{ flex: 1, backgroundColor: '#f1f5f9', color: '#64748b', padding: '1rem', borderRadius: '12px', fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem' }}>
              <Printer size={18} /> Save & Print Slip
            </button>
          </div>
        </form>
      </Drawer>
    </div>
  );
};

export default Appointments;
