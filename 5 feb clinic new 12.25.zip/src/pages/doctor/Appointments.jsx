import React, { useState } from 'react';
import { Eye, CheckCircle, XCircle, Play, ClipboardList, History, Phone, User, Calendar as CalendarIcon, Clock, Search, Filter } from 'lucide-react';
import { SectionHeader } from '../../components/DashboardElements';
import { MOCK_APPOINTMENTS } from '../../data/mockData';
import Drawer from '../../components/Drawer.jsx';

const Appointments = () => {
  const [selectedAppt, setSelectedAppt] = useState(null);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');

  const filteredAppointments = MOCK_APPOINTMENTS.filter(appt => {
    const matchesSearch = appt.patient.toLowerCase().includes(searchTerm.toLowerCase()) ||
      appt.appId.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'All' || appt.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleViewDetails = (appt) => {
    setSelectedAppt(appt);
    setIsDrawerOpen(true);
  };

  const labelStyle = {
    display: 'block',
    fontSize: '0.75rem',
    fontWeight: 700,
    color: 'var(--text-muted)',
    textTransform: 'uppercase',
    marginBottom: '0.25rem'
  };

  return (
    <div className="fade-in">
      <SectionHeader title="Appointments" desc="Manage your consultation schedule and patient visits." />

      <div className="card" style={{ marginBottom: '1.5rem', padding: '1rem', backgroundColor: 'var(--bg-sidebar)' }}>
        <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
          <div style={{ flex: 1, minWidth: '250px', position: 'relative' }}>
            <Search size={18} color="var(--text-muted)" style={{ position: 'absolute', left: '1rem', top: '50%', transform: 'translateY(-50%)' }} />
            <input
              type="text"
              placeholder="Search by patient name or ID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              style={{ width: '100%', padding: '0.75rem 1rem 0.75rem 2.8rem', borderRadius: '10px', border: '1px solid var(--border)', backgroundColor: 'var(--bg-main)', color: 'var(--text-main)', outline: 'none' }}
            />
          </div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            style={{ padding: '0 1rem', borderRadius: '10px', border: '1px solid var(--border)', backgroundColor: 'var(--bg-main)', color: 'var(--text-main)', outline: 'none', height: '44px' }}
          >
            <option value="All">All Status</option>
            <option value="Confirmed">Confirmed</option>
            <option value="Completed">Completed</option>
            <option value="Cancelled">Cancelled</option>
          </select>
        </div>
      </div>

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>Appt ID</th>
              <th>Patient Name</th>
              <th>Age / Gender</th>
              <th>Date</th>
              <th>Time Slot</th>
              <th>Visit Type</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredAppointments.map(appt => (
              <tr key={appt.id}>
                <td data-label="Appt ID"><span style={{ fontWeight: 600, color: 'var(--text-muted)' }}>{appt.appId}</span></td>
                <td data-label="Patient Name"><b style={{ color: 'var(--heading)' }}>{appt.patient}</b></td>
                <td data-label="Age / Gender" style={{ color: 'var(--text-main)' }}>{appt.age} / {appt.gender}</td>
                <td data-label="Date" style={{ color: 'var(--text-main)' }}>{appt.date}</td>
                <td data-label="Time Slot"><div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', color: 'var(--text-main)' }}><Clock size={14} color="var(--text-muted)" /> {appt.time}</div></td>
                <td data-label="Visit Type"><span className="badge badge-blue">{appt.type}</span></td>
                <td data-label="Status"><span className={`badge ${appt.status === 'Completed' ? 'badge-success' : appt.status === 'Confirmed' ? 'badge-blue' : 'badge-warning'}`}>{appt.status}</span></td>
                <td data-label="Actions">
                  <div style={{ display: 'flex', gap: '0.5rem' }}>
                    <button className="action-btn" title="View Details" onClick={() => handleViewDetails(appt)} style={{ backgroundColor: 'var(--bg-sidebar)' }}><Eye size={18} color="var(--primary)" /></button>

                    <button className="action-btn" title="Mark Completed" style={{ backgroundColor: 'var(--bg-sidebar)' }}><CheckCircle size={18} color="var(--accent)" /></button>
                    <button className="action-btn" title="Cancel" style={{ backgroundColor: 'var(--bg-sidebar)' }}><XCircle size={18} color="var(--danger)" /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Drawer isOpen={isDrawerOpen} onClose={() => setIsDrawerOpen(false)} title="Appointment Details">
        {selectedAppt && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
            {/* Patient Info Section */}
            <div style={{ backgroundColor: 'var(--bg-main)', padding: '1.5rem', borderRadius: '16px', border: '1px solid var(--border)' }}>
              <h4 style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '1rem', color: 'var(--heading)' }}><User size={18} /> Patient Information</h4>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                <div><label style={labelStyle}>Patient Name</label><p style={{ fontWeight: 600, color: 'var(--heading)' }}>{selectedAppt.patient}</p></div>
                <div><label style={labelStyle}>Mobile</label><p style={{ fontWeight: 600, display: 'flex', alignItems: 'center', gap: '0.4rem', color: 'var(--text-main)' }}><Phone size={14} /> 9876543210</p></div>
                <div><label style={labelStyle}>Age</label><p style={{ fontWeight: 600, color: 'var(--text-main)' }}>{selectedAppt.age} years</p></div>
                <div><label style={labelStyle}>Gender</label><p style={{ fontWeight: 600, color: 'var(--text-main)' }}>{selectedAppt.gender}</p></div>
              </div>
            </div>

            {/* Appointment Info */}
            <div>
              <h4 style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '1rem', color: 'var(--heading)' }}><CalendarIcon size={18} /> Appointment Info</h4>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
                <div><label style={labelStyle}>Date</label><p style={{ fontWeight: 600, color: 'var(--text-main)' }}>{selectedAppt.date}</p></div>
                <div><label style={labelStyle}>Time Slot</label><p style={{ fontWeight: 600, color: 'var(--text-main)' }}>{selectedAppt.time}</p></div>
                <div><label style={labelStyle}>Visit Type</label><p><span className="badge badge-blue">{selectedAppt.type}</span></p></div>
                <div style={{ gridColumn: 'span 2' }}>
                  <label style={labelStyle}>Doctor Notes</label>
                  <p style={{ color: 'var(--text-muted)' }}>Patient complained of severe chest pain and breathlessness. Previous history of blood pressure documented.</p>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div style={{ display: 'flex', gap: '1rem', marginTop: '1rem' }}>
              <button style={{ flex: 1, backgroundColor: 'var(--primary)', color: 'white', padding: '1rem', borderRadius: '14px', fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem' }}>
                <ClipboardList size={20} /> Create Prescription
              </button>
              <button style={{ flex: 1, backgroundColor: 'var(--bg-main)', color: 'var(--text-main)', padding: '1rem', borderRadius: '14px', fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem', border: '1px solid var(--border)' }}>
                <History size={20} /> View Patient History
              </button>
            </div>
          </div>
        )}
      </Drawer>
    </div>
  );
};

export default Appointments;
