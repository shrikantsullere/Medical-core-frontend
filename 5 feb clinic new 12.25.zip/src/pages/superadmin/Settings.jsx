import React, { useState } from 'react';
import { Mail, MessageSquare, FileText, Save, Send, Eye, ShieldCheck, Globe } from 'lucide-react';
import { SectionHeader } from '../../components/DashboardElements';

const Settings = () => {
  const [activeTab, setActiveTab] = useState('email');

  const inputStyle = {
    width: '100%',
    padding: '0.75rem',
    borderRadius: '10px',
    border: '1px solid #e2e8f0',
    fontSize: '0.9rem',
    outline: 'none',
  };

  const labelStyle = {
    display: 'block',
    fontSize: '0.8rem',
    fontWeight: 700,
    color: '#475569',
    marginBottom: '0.5rem',
    textTransform: 'uppercase',
  };

  const cardStyle = {
    backgroundColor: 'white',
    borderRadius: '20px',
    padding: '2rem',
    border: '1px solid #e2e8f0',
    boxShadow: '0 4px 6px -1px rgba(0,0,0,0.05)'
  };

  return (
    <div className="fade-in">
      <SectionHeader title="System Settings" desc="Configure global system parameters, integrations, and branding." />

      <div style={{ display: 'flex', gap: '1rem', marginBottom: '2rem' }}>
        {[
          { id: 'email', label: 'Email (SMTP)', icon: Mail },
          { id: 'sms', label: 'SMS Gateway', icon: MessageSquare },
          { id: 'invoice', label: 'Invoice Design', icon: FileText },
          { id: 'general', label: 'General', icon: Globe },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem',
              padding: '0.75rem 1.25rem',
              borderRadius: '12px',
              backgroundColor: activeTab === tab.id ? '#7c3aed' : 'white',
              color: activeTab === tab.id ? 'white' : '#64748b',
              fontWeight: 600,
              border: activeTab === tab.id ? 'none' : '1px solid #e2e8f0',
              transition: 'all 0.2s'
            }}
          >
            <tab.icon size={18} />
            {tab.label}
          </button>
        ))}
      </div>

      {activeTab === 'email' && (
        <div className="fade-in" style={cardStyle}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
            <h3 style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}><Mail /> SMTP Configuration</h3>
            <button style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: '#7c3aed', fontWeight: 600, fontSize: '0.875rem' }}>
              <Send size={16} /> Send Test Email
            </button>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr', gap: '2rem' }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                <div>
                  <label style={labelStyle}>SMTP Host</label>
                  <input type="text" defaultValue="smtp.gmail.com" style={inputStyle} />
                </div>
                <div>
                  <label style={labelStyle}>SMTP Port</label>
                  <input type="text" defaultValue="587" style={inputStyle} />
                </div>
              </div>
              <div>
                <label style={labelStyle}>Username</label>
                <input type="text" defaultValue="notifications@medcare.com" style={inputStyle} />
              </div>
              <div>
                <label style={labelStyle}>Password</label>
                <input type="password" defaultValue="********" style={inputStyle} />
              </div>
              <div>
                <label style={labelStyle}>From Email Address</label>
                <input type="email" defaultValue="support@medcare.com" style={inputStyle} />
              </div>
              <button style={{ alignSelf: 'flex-start', backgroundColor: '#7c3aed', color: 'white', padding: '0.75rem 2rem', borderRadius: '12px', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <Save size={18} /> Save Settings
              </button>
            </div>
            <div style={{ backgroundColor: '#f8fafc', padding: '1.5rem', borderRadius: '16px', border: '1px solid #f1f5f9' }}>
              <h4 style={{ marginBottom: '1rem', fontSize: '0.9rem', color: '#475569' }}>Instructions</h4>
              <p style={{ fontSize: '0.85rem', color: '#64748b', lineHeight: 1.6 }}>
                Make sure your SMTP server allows connections from this IP. If using Gmail, you might need to generate an <b>App Password</b>.
              </p>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'sms' && (
        <div className="fade-in" style={cardStyle}>
          <h3 style={{ marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '0.75rem' }}><MessageSquare /> SMS Gateway</h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem', maxWidth: '600px' }}>
            <div>
              <label style={labelStyle}>Provider</label>
              <select style={inputStyle}>
                <option>Twilio</option>
                <option>AWS SNS</option>
                <option>TextLocal</option>
              </select>
            </div>
            <div>
              <label style={labelStyle}>API Key</label>
              <input type="text" placeholder="Enter API Key" style={inputStyle} />
            </div>
            <div>
              <label style={labelStyle}>Sender ID</label>
              <input type="text" placeholder="MEDCAR" style={inputStyle} />
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <input type="checkbox" id="smsEnabled" style={{ width: '18px', height: '18px' }} />
              <label htmlFor="smsEnabled" style={{ fontWeight: 600, color: '#475569' }}>Enable SMS Service System-wide</label>
            </div>
            <button style={{ alignSelf: 'flex-start', backgroundColor: '#7c3aed', color: 'white', padding: '0.75rem 2rem', borderRadius: '12px', fontWeight: 700 }}>Save Configurations</button>
          </div>
        </div>
      )}

      {activeTab === 'invoice' && (
        <div className="fade-in" style={cardStyle}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
            <h3 style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}><FileText /> Invoice Branding</h3>
            <button style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: '#64748b', fontWeight: 600, fontSize: '0.875rem', padding: '0.5rem 1rem', borderRadius: '8px', border: '1px solid #e2e8f0' }}>
              <Eye size={16} /> Preview PDF
            </button>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '2rem' }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
              <div>
                <label style={labelStyle}>Invoice Header Text</label>
                <input type="text" placeholder="e.g. MedCare Professional Clinic Solutions" style={inputStyle} />
              </div>
              <div>
                <label style={labelStyle}>Footer Text</label>
                <textarea placeholder="e.g. This is a computer generated invoice." style={{ ...inputStyle, height: '80px' }} />
              </div>
              <div>
                <label style={labelStyle}>Terms & Conditions</label>
                <textarea placeholder="e.g. 1. No refunds on subscriptions." style={{ ...inputStyle, height: '120px' }} />
              </div>
              <button style={{ alignSelf: 'flex-start', backgroundColor: '#7c3aed', color: 'white', padding: '0.75rem 2rem', borderRadius: '12px', fontWeight: 700 }}>Save Template</button>
            </div>
            <div style={{ border: '2px dashed #cbd5e1', borderRadius: '16px', display: 'flex', alignItems: 'center', justifySelf: 'center', width: '100%', padding: '2rem', textAlign: 'center', color: '#94a3b8' }}>
              <div style={{ margin: '0 auto' }}>
                <div style={{ width: '80px', height: '80px', backgroundColor: '#f1f5f9', borderRadius: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 1rem' }}>
                  <ShieldCheck size={40} />
                </div>
                <p style={{ fontWeight: 600 }}>System Default Template</p>
                <p style={{ fontSize: '0.8rem' }}>Upload dynamic tags like {`{invoice_id}`} in your template editor.</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Settings;
