import React, { useState } from 'react';
import { Eye, History, Search, Filter, User, Info, FileText, Wallet } from 'lucide-react';
import { SectionHeader } from '../../components/DashboardElements';
import { MOCK_PATIENTS, MOCK_APPOINTMENTS, MOCK_PRESCRIPTIONS, MOCK_INVOICES } from '../../data/mockData';
import Drawer from '../../components/Drawer.jsx';

const Patients = () => {
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('Personal Info');

  const handleViewProfile = (patient) => {
    setSelectedPatient(patient);
    setActiveTab('Personal Info');
    setIsDrawerOpen(true);
  };

  const labelStyle = {
    display: 'block',
    fontSize: '0.8rem',
    fontWeight: 700,
    color: '#94a3b8',
    textTransform: 'uppercase',
    marginBottom: '0.4rem'
  };

  return (
    <div className="fade-in">
      <SectionHeader title="Your Patients" desc="List of patients assigned to you for consultation." />

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>Patient Name</th>
              <th>Mobile</th>
              <th>Last Visit</th>
              <th>Total Visits</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {MOCK_PATIENTS.map(patient => (
              <tr key={patient.id}>
                <td data-label="Patient Name">
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                    <div style={{ width: '32px', height: '32px', borderRadius: '50%', backgroundColor: 'var(--bg-header)', color: 'var(--primary)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700 }}>{patient.name.charAt(0)}</div>
                    <b>{patient.name}</b>
                  </div>
                </td>
                <td data-label="Mobile">{patient.mobile}</td>
                <td data-label="Last Visit">{patient.lastVisit}</td>
                <td data-label="Visits"><span className="badge badge-blue">{patient.totalVisits} visits</span></td>
                <td data-label="Actions">
                  <div style={{ display: 'flex', gap: '0.5rem' }}>
                    <button className="action-btn" onClick={() => handleViewProfile(patient)} title="View Profile"><Eye size={18} color="var(--primary)" /></button>
                    <button className="action-btn" title="View History"><History size={18} color="var(--secondary)" /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Drawer isOpen={isDrawerOpen} onClose={() => setIsDrawerOpen(false)} title="Patient Profile">
        {selectedPatient && (
          <div>
            {/* Header Brief */}
            <div style={{ display: 'flex', gap: '1.5rem', alignItems: 'center', marginBottom: '2rem' }}>
              <div style={{ width: '70px', height: '70px', borderRadius: '20px', backgroundColor: '#f5f3ff', color: '#7c3aed', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.75rem', fontWeight: 800 }}>
                {selectedPatient.name.charAt(0)}
              </div>
              <div>
                <h2 style={{ fontSize: '1.5rem', color: '#1e293b' }}>{selectedPatient.name}</h2>
                <p style={{ color: '#64748b', fontWeight: 600 }}>ID: {selectedPatient.patientId} • {selectedPatient.gender}, {selectedPatient.age} yrs</p>
              </div>
            </div>

            {/* Read-only Tabs */}
            <div style={{ display: 'flex', gap: '1rem', borderBottom: '1px solid #e2e8f0', marginBottom: '1.5rem' }}>
              {['Personal Info', 'Visit History', 'Prescriptions', 'Bills'].map(tab => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  style={{
                    padding: '0.75rem 0.5rem',
                    color: activeTab === tab ? '#7c3aed' : '#94a3b8',
                    borderBottom: `2px solid ${activeTab === tab ? '#7c3aed' : 'transparent'}`,
                    fontWeight: 600,
                    fontSize: '0.9rem',
                    backgroundColor: 'transparent'
                  }}
                >
                  {tab}
                </button>
              ))}
            </div>

            <div style={{ minHeight: '300px' }}>
              {activeTab === 'Personal Info' && (
                <div className="fade-in" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
                  <div><label style={labelStyle}>Blood Group</label><p style={{ fontWeight: 600 }}>{selectedPatient.bloodGroup}</p></div>
                  <div><label style={labelStyle}>Email</label><p style={{ fontWeight: 600 }}>sneha@example.com</p></div>
                  <div style={{ gridColumn: 'span 2' }}><label style={labelStyle}>Permanent Address</label><p style={{ fontWeight: 600 }}>Flat 402, Garden View Apt, Pune, Maharashtra - 411001</p></div>
                  <div style={{ gridColumn: 'span 2' }}>
                    <label style={labelStyle}>Emergency Contact</label>
                    <p style={{ fontWeight: 600 }}>Rajesh Patel (Husband) - 9898989898</p>
                  </div>
                </div>
              )}

              {activeTab === 'Visit History' && (
                <div className="fade-in" style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                  {MOCK_APPOINTMENTS.map(app => (
                    <div key={app.id} style={{ padding: '1rem', border: '1px solid #f1f5f9', borderRadius: '12px' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
                        <span style={{ fontWeight: 700 }}>{app.date}</span>
                        <span className="badge badge-success">Completed</span>
                      </div>
                      <p style={{ fontSize: '0.85rem', color: '#64748b' }}>Reason: Regular Checkup • Type: {app.type}</p>
                    </div>
                  ))}
                </div>
              )}

              {activeTab === 'Prescriptions' && (
                <div className="fade-in" style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                  {MOCK_PRESCRIPTIONS.map(rx => (
                    <div key={rx.id} style={{ padding: '1rem', border: '1px solid #f1f5f9', borderRadius: '12px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <div>
                        <p style={{ fontWeight: 700 }}>{rx.rxId}</p>
                        <p style={{ fontSize: '0.8rem', color: '#64748b' }}>{rx.date}</p>
                      </div>
                      <button className="action-btn" title="View PDF"><FileText size={16} color="#6366f1" /></button>
                    </div>
                  ))}
                </div>
              )}

              {activeTab === 'Bills' && (
                <div className="fade-in" style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                  {MOCK_INVOICES.map(inv => (
                    <div key={inv.id} style={{ padding: '1rem', border: '1px solid #f1f5f9', borderRadius: '12px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <div>
                        <p style={{ fontWeight: 700 }}>{inv.invId}</p>
                        <p style={{ fontSize: '0.8rem', color: '#64748b' }}>{inv.date}</p>
                      </div>
                      <p style={{ fontWeight: 800, color: '#10b981' }}>{inv.total}</p>
                    </div>
                  ))}
                  <p style={{ fontSize: '0.75rem', color: '#ef4444', textAlign: 'center', marginTop: '1rem' }}>Notice: Billing details are read-only for Doctors.</p>
                </div>
              )}
            </div>
          </div>
        )}
      </Drawer>
    </div>
  );
};

export default Patients;
