import React, { useState } from 'react';
import { User, Phone, Mail, Home, Shield, Lock, LogOut, Save, Calendar } from 'lucide-react';
import { SectionHeader } from '../../components/DashboardElements';

const Profile = () => {
  const [activeTab, setActiveTab] = useState('profile');

  const labelStyle = {
    display: 'block',
    fontSize: '0.8rem',
    fontWeight: 700,
    color: '#94a3b8',
    textTransform: 'uppercase',
    marginBottom: '0.4rem'
  };

  const inputStyle = {
    width: '100%',
    padding: '0.75rem',
    borderRadius: '10px',
    border: '1px solid #e2e8f0',
    fontSize: '0.9rem',
    outline: 'none',
  };

  return (
    <div className="fade-in">
      <SectionHeader title="Profile & Settings" desc="Manage your personal health profile and account security." />

      <div style={{ display: 'flex', gap: '1rem', borderBottom: '1px solid #e2e8f0', marginBottom: '2rem' }}>
        <button
          onClick={() => setActiveTab('profile')}
          style={{ padding: '1rem', color: activeTab === 'profile' ? '#7c3aed' : '#94a3b8', borderBottom: `2px solid ${activeTab === 'profile' ? '#7c3aed' : 'transparent'}`, fontWeight: 600, backgroundColor: 'transparent' }}
        >
          My Profile
        </button>
        <button
          onClick={() => setActiveTab('settings')}
          style={{ padding: '1rem', color: activeTab === 'settings' ? '#7c3aed' : '#94a3b8', borderBottom: `2px solid ${activeTab === 'settings' ? '#7c3aed' : 'transparent'}`, fontWeight: 600, backgroundColor: 'transparent' }}
        >
          Account Settings
        </button>
      </div>

      <div style={{ maxWidth: '700px' }}>
        {activeTab === 'profile' ? (
          <div className="fade-in">
            <div className="card" style={{ marginBottom: '1.5rem' }}>
              <h3 style={{ marginBottom: '1.5rem', fontSize: '1.1rem' }}>Personal Information</h3>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
                <div style={{ gridColumn: 'span 2' }}>
                  <label style={labelStyle}>Full Name</label>
                  <input type="text" defaultValue="Deepak Verma" style={inputStyle} />
                </div>
                <div>
                  <label style={labelStyle}>Mobile Number</label>
                  <input type="tel" defaultValue="9898989898" style={inputStyle} />
                </div>
                <div>
                  <label style={labelStyle}>Email Address</label>
                  <input type="email" defaultValue="deepak@demo.com" style={inputStyle} />
                </div>
                <div>
                  <label style={labelStyle}>Gender</label>
                  <select style={inputStyle} defaultValue="Male">
                    <option>Male</option>
                    <option>Female</option>
                    <option>Other</option>
                  </select>
                </div>
                <div>
                  <label style={labelStyle}>DOB / Age</label>
                  <input type="text" defaultValue="15-05-1990 (34 years)" style={inputStyle} />
                </div>
                <div style={{ gridColumn: 'span 2' }}>
                  <label style={labelStyle}>Residential Address</label>
                  <textarea defaultValue="123, Health Enclave, New Delhi - 110001" style={{ ...inputStyle, height: '80px' }} />
                </div>
              </div>
            </div>
            <button style={{ width: '100%', backgroundColor: '#7c3aed', color: 'white', padding: '1rem', borderRadius: '12px', fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem' }}>
              <Save size={18} /> Update My Profile
            </button>
          </div>
        ) : (
          <div className="fade-in">
            <div className="card" style={{ marginBottom: '1.5rem' }}>
              <h3 style={{ marginBottom: '1.5rem', fontSize: '1.1rem' }}>Change Account Password</h3>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
                <div>
                  <label style={labelStyle}>Current Password</label>
                  <input type="password" style={inputStyle} />
                </div>
                <div>
                  <label style={labelStyle}>New Password</label>
                  <input type="password" style={inputStyle} />
                </div>
                <button style={{ backgroundColor: '#7c3aed', color: 'white', padding: '0.8rem', borderRadius: '10px', fontWeight: 700 }}>
                  Change Password
                </button>
              </div>
            </div>

            <div className="card" style={{ border: '1px solid #fee2e2' }}>
              <h3 style={{ color: '#ef4444', marginBottom: '1rem', fontSize: '1.1rem' }}>Sign Out Options</h3>
              <p style={{ color: '#64748b', fontSize: '0.9rem', marginBottom: '1.5rem' }}>Protect your healthcare data by logging out from public devices.</p>
              <button style={{ backgroundColor: '#fef2f2', color: '#ef4444', padding: '1rem', borderRadius: '12px', fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem', border: '1px solid #fee2e2' }}>
                <LogOut size={18} /> Logout from all devices
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Profile;
