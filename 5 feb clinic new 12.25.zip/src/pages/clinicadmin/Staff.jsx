import React, { useState } from 'react';
import { UserPlus, Edit, KeyRound, Ban, CheckCircle } from 'lucide-react';
import { SectionHeader } from '../../components/DashboardElements';
import { MOCK_STAFF } from '../../data/mockData';
import Drawer from '../../components/Drawer.jsx';

const Staff = () => {
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  const inputStyle = {
    width: '100%',
    padding: '0.75rem',
    borderRadius: '10px',
    border: '1px solid #e2e8f0',
    fontSize: '0.9rem',
    outline: 'none',
  };

  const labelStyle = {
    display: 'block',
    fontSize: '0.8rem',
    fontWeight: 700,
    color: '#475569',
    marginBottom: '0.4rem',
    textTransform: 'uppercase',
  };

  return (
    <div className="fade-in">
      <SectionHeader
        title="Staff & Roles"
        desc="Manage clinic employees and permissions."
        actionLabel="Add Staff"
        onAction={() => setIsDrawerOpen(true)}
      />

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>Staff Name</th>
              <th>Role</th>
              <th>Mobile</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {MOCK_STAFF.map(staff => (
              <tr key={staff.id}>
                <td data-label="Staff Name"><b>{staff.name}</b></td>
                <td data-label="Role"><span className="badge badge-blue">{staff.role}</span></td>
                <td data-label="Mobile">{staff.mobile}</td>
                <td data-label="Status">
                  <span className={`badge ${staff.status === 'Active' ? 'badge-success' : 'badge-danger'}`}>
                    {staff.status}
                  </span>
                </td>
                <td data-label="Actions">
                  <div style={{ display: 'flex', gap: '0.5rem' }}>
                    <button className="action-btn" title="Edit"><Edit size={16} color="#3b82f6" /></button>
                   
                    <button className="action-btn" title="Block"><Ban size={16} color="#ef4444" /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Drawer isOpen={isDrawerOpen} onClose={() => setIsDrawerOpen(false)} title="Add Staff Member">
        <form style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          <div>
            <label style={labelStyle}>Full Name *</label>
            <input type="text" placeholder="Staff Name" style={inputStyle} required />
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
            <div>
              <label style={labelStyle}>Email (Login) *</label>
              <input type="email" placeholder="staff@clinic.com" style={inputStyle} required />
            </div>
            <div>
              <label style={labelStyle}>Login Password *</label>
              <input type="password" placeholder="Set Password" style={inputStyle} required />
            </div>
            <div>
              <label style={labelStyle}>Mobile *</label>
              <input type="tel" placeholder="00000 00000" style={inputStyle} required />
            </div>
          </div>
          <div>
            <label style={labelStyle}>Role *</label>
            <select style={inputStyle} required>
              <option>Receptionist</option>
              <option>Accountant</option>
              <option>Nurse / Staff</option>
            </select>
          </div>
          <div>
            <label style={labelStyle}>Permissions</label>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem', marginTop: '0.5rem' }}>
              {['Manage Patients', 'Create Appointments', 'Billing Access', 'Report Access', 'Emergency Override'].map(p => (
                <label key={p} style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.85rem', color: '#64748b', cursor: 'pointer' }}>
                  <input type="checkbox" /> {p}
                </label>
              ))}
            </div>
          </div>
          <button className="btn-primary" style={{ backgroundColor: '#7c3aed', color: 'white', padding: '1rem', borderRadius: '12px', fontWeight: 700, marginTop: '1rem' }}>Save</button>
        </form>
      </Drawer>
    </div>
  );
};

export default Staff;
