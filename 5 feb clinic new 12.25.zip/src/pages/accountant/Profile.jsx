import React, { useState } from 'react';
import { User, Shield, Save, LogOut, KeyRound, Mail, Phone } from 'lucide-react';
import { SectionHeader } from '../../components/DashboardElements';

const Profile = () => {
  const [activeTab, setActiveTab] = useState('profile');

  const labelStyle = {
    display: 'block',
    fontSize: '0.8rem',
    fontWeight: 700,
    color: '#94a3b8',
    textTransform: 'uppercase',
    marginBottom: '0.4rem'
  };

  const inputStyle = {
    width: '100%',
    padding: '0.75rem',
    borderRadius: '10px',
    border: '1px solid #e2e8f0',
    fontSize: '0.9rem',
    outline: 'none',
  };

  return (
    <div className="fade-in">
      <SectionHeader title="Your Profile" desc="Manage your personal accountant information and security." />

      <div style={{ display: 'flex', gap: '1rem', borderBottom: '1px solid #e2e8f0', marginBottom: '2rem' }}>
        <button
          onClick={() => setActiveTab('profile')}
          style={{ padding: '1rem', color: activeTab === 'profile' ? '#7c3aed' : '#94a3b8', borderBottom: `2px solid ${activeTab === 'profile' ? '#7c3aed' : 'transparent'}`, fontWeight: 600, backgroundColor: 'transparent' }}
        >
          Accountant Profile
        </button>
        <button
          onClick={() => setActiveTab('security')}
          style={{ padding: '1rem', color: activeTab === 'security' ? '#7c3aed' : '#94a3b8', borderBottom: `2px solid ${activeTab === 'security' ? '#7c3aed' : 'transparent'}`, fontWeight: 600, backgroundColor: 'transparent' }}
        >
          Account Settings
        </button>
      </div>

      <div style={{ maxWidth: '600px' }}>
        {activeTab === 'profile' ? (
          <div className="card fade-in">
            <h3 style={{ marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}><User size={20} /> Basic Information</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
              <div>
                <label style={labelStyle}>Full Name</label>
                <input type="text" defaultValue="Kushal Dev" style={inputStyle} />
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                <div>
                  <label style={labelStyle}>Email Address</label>
                  <input type="email" defaultValue="kushal@clinic.com" style={inputStyle} />
                </div>
                <div>
                  <label style={labelStyle}>Mobile Number</label>
                  <input type="tel" defaultValue="9898989800" style={inputStyle} />
                </div>
              </div>
              <div>
                <label style={labelStyle}>Professional Role (Read-only)</label>
                <div style={{ ...inputStyle, backgroundColor: '#f8fafc', color: '#64748b', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <Shield size={16} /> Accountant & Financial Head
                </div>
              </div>
              <button style={{ backgroundColor: '#7c3aed', color: 'white', padding: '1rem', borderRadius: '12px', fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem', marginTop: '1rem' }}>
                <Save size={18} /> Save Profile
              </button>
            </div>
          </div>
        ) : (
          <div className="card fade-in">
            <h3 style={{ marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}><KeyRound size={20} /> Change Password</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
              <div>
                <label style={labelStyle}>Current Password</label>
                <input type="password" style={inputStyle} />
              </div>
              <div>
                <label style={labelStyle}>New Password</label>
                <input type="password" style={inputStyle} />
              </div>
              <button style={{ backgroundColor: '#7c3aed', color: 'white', padding: '1rem', borderRadius: '12px', fontWeight: 700, marginTop: '0.5rem' }}>
                Update Password
              </button>

              <hr style={{ border: 'none', borderTop: '1px solid #e2e8f0', margin: '1rem 0' }} />

              <button style={{ backgroundColor: '#fee2e2', color: '#ef4444', padding: '1rem', borderRadius: '12px', fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem' }}>
                <LogOut size={18} /> Logout from all devices
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Profile;
