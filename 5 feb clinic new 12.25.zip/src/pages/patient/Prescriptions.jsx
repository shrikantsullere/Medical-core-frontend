import React, { useState } from 'react';
import { Eye, Download, Search, ClipboardList, User, Calendar, Droplets, Info } from 'lucide-react';
import { SectionHeader } from '../../components/DashboardElements';
import { MOCK_PRESCRIPTIONS } from '../../data/mockData';
import Drawer from '../../components/Drawer.jsx';

const Prescriptions = () => {
  const [selectedRx, setSelectedRx] = useState(null);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  const handleViewRx = (rx) => {
    setSelectedRx(rx);
    setIsDrawerOpen(true);
  };

  const labelStyle = {
    display: 'block',
    fontSize: '0.75rem',
    fontWeight: 700,
    color: '#94a3b8',
    textTransform: 'uppercase',
    marginBottom: '0.25rem'
  };

  return (
    <div className="fade-in">
      <SectionHeader title="Prescriptions" desc="Access your digital prescriptions and medical advice." />

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>Prescription ID</th>
              <th>Doctor Name</th>
              <th>Date</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {MOCK_PRESCRIPTIONS.map(rx => (
              <tr key={rx.id}>
                <td><span style={{ fontWeight: 600 }}>{rx.rxId}</span></td>
                <td><b>Dr. Sameer Khan</b></td>
                <td>{rx.date}</td>
                <td><span className="badge badge-blue">{rx.status}</span></td>
                <td>
                  <div style={{ display: 'flex', gap: '0.5rem' }}>
                    <button className="action-btn" onClick={() => handleViewRx(rx)} title="View Prescription"><Eye size={18} color="#6366f1" /></button>
                    <button className="action-btn" title="Download PDF"><Download size={18} color="#10b981" /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Drawer isOpen={isDrawerOpen} onClose={() => setIsDrawerOpen(false)} title="Prescription View">
        {selectedRx && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
            {/* Header info */}
            <div style={{ display: 'flex', gap: '1rem', alignItems: 'center', backgroundColor: '#f8fafc', padding: '1.25rem', borderRadius: '16px', border: '1px solid #e2e8f0' }}>
              <div style={{ width: '50px', height: '50px', borderRadius: '12px', backgroundColor: '#7c3aed', color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <User size={24} />
              </div>
              <div>
                <h3 style={{ fontSize: '1.1rem' }}>Dr. Sameer Khan</h3>
                <p style={{ color: '#64748b', fontSize: '0.85rem' }}>Cardiology Specialists • City Dental Clinic</p>
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <div>
                <label style={labelStyle}>Diagnosis</label>
                <div style={{ padding: '0.75rem', border: '1px solid #f1f5f9', borderRadius: '10px', fontSize: '0.9rem', fontWeight: 600 }}>Mild Hypertension & Anxiety</div>
              </div>
              <div>
                <label style={labelStyle}>Follow-up Date</label>
                <div style={{ padding: '0.75rem', border: '1px solid #f1f5f9', borderRadius: '10px', fontSize: '0.9rem', fontWeight: 600, color: '#7c3aed' }}>05 April 2024</div>
              </div>
            </div>

            {/* Medicines */}
            <div>
              <label style={labelStyle}>Medicines & Dosage</label>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                {[
                  { name: 'Telmisartan 40mg', dose: '1-0-0', duration: '30 Days', instruction: 'Before Food' },
                  { name: 'Paracetamol 650mg', dose: '1-1-1', duration: '5 Days', instruction: 'After Food' }
                ].map((med, i) => (
                  <div key={i} style={{ padding: '1rem', border: '1px solid #f1f5f9', borderRadius: '12px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div>
                      <p style={{ fontWeight: 700 }}>{med.name}</p>
                      <p style={{ fontSize: '0.8rem', color: '#64748b' }}>{med.instruction}</p>
                    </div>
                    <div style={{ textAlign: 'right' }}>
                      <span style={{ backgroundColor: '#f5f3ff', color: '#7c3aed', padding: '0.25rem 0.6rem', borderRadius: '8px', fontSize: '0.8rem', fontWeight: 700 }}>{med.dose}</span>
                      <p style={{ fontSize: '0.8rem', color: '#64748b', marginTop: '0.25rem' }}>{med.duration}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Advice */}
            <div style={{ backgroundColor: '#fffbeb', border: '1px solid #fef3c7', padding: '1.25rem', borderRadius: '14px' }}>
              <h4 style={{ color: '#92400e', marginBottom: '0.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}><Info size={18} /> Doctor's Advice</h4>
              <p style={{ fontSize: '0.9rem', color: '#92400e', lineHeight: 1.5 }}>
                Avoid oily food and salt intake. Exercise for 30 mins daily. Take plenty of water.
              </p>
            </div>

            <button style={{ backgroundColor: '#7c3aed', color: 'white', padding: '1rem', borderRadius: '12px', fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem', marginTop: '1rem' }}>
              <Download size={18} /> Download Digital Copy (PDF)
            </button>
          </div>
        )}
      </Drawer>
    </div>
  );
};

export default Prescriptions;
