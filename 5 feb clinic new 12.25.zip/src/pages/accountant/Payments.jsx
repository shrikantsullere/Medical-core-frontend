import React, { useState } from 'react';
import { Eye, Printer, Search, Plus, Save, Calendar, FileText, CreditCard } from 'lucide-react';
import { SectionHeader } from '../../components/DashboardElements';
import { MOCK_PAYMENTS, MOCK_INVOICES } from '../../data/mockData';
import Drawer from '../../components/Drawer.jsx';

const Payments = () => {
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  const labelStyle = {
    display: 'block',
    fontSize: '0.75rem',
    fontWeight: 700,
    color: '#94a3b8',
    textTransform: 'uppercase',
    marginBottom: '0.3rem'
  };

  const inputStyle = {
    width: '100%',
    padding: '0.75rem',
    borderRadius: '10px',
    border: '1px solid #e2e8f0',
    fontSize: '0.9rem',
    outline: 'none',
  };

  return (
    <div className="fade-in">
      <SectionHeader
        title="Payment Collections"
        desc="Post and adjust patient payments across all modes."
        actionLabel="Add / Adjust Payment"
        onAction={() => setIsDrawerOpen(true)}
      />

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>Receipt No</th>
              <th>Invoice No</th>
              <th>Patient Name</th>
              <th>Amount</th>
              <th>Mode</th>
              <th>Ref / TXN ID</th>
              <th>Date</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {MOCK_PAYMENTS.map(p => (
              <tr key={p.id}>
                <td><span style={{ fontWeight: 600, color: '#6366f1' }}>{p.txId}</span></td>
                <td><span style={{ color: '#64748b' }}>{p.invId}</span></td>
                <td><b>{p.clinic}</b></td>
                <td style={{ fontWeight: 700 }}>{p.amount}</td>
                <td><span className="badge badge-blue">{p.mode}</span></td>
                <td><code style={{ fontSize: '0.8rem' }}>TXN_987654</code></td>
                <td>{p.date}</td>
                <td>
                  <div style={{ display: 'flex', gap: '0.5rem' }}>
                    <button className="action-btn" title="View Receipt"><Eye size={16} color="#6366f1" /></button>
                    <button className="action-btn" title="Print"><Printer size={16} color="#64748b" /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Drawer isOpen={isDrawerOpen} onClose={() => setIsDrawerOpen(false)} title="Add / Adjust Payment">
        <form style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          <div>
            <label style={labelStyle}>Invoice Number *</label>
            <select style={inputStyle} required>
              <option value="">Select Invoice</option>
              {MOCK_INVOICES.map(inv => <option key={inv.id}>{inv.invId} - {inv.patient} ({inv.total})</option>)}
            </select>
          </div>
          <div>
            <label style={labelStyle}>Payment Amount ($) *</label>
            <input type="number" placeholder="Enter Amount" style={inputStyle} required />
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
            <div>
              <label style={labelStyle}>Payment Mode *</label>
              <select style={inputStyle} required>
                <option>Cash</option>
                <option>UPI</option>
                <option>Card</option>
                <option>Online</option>
              </select>
            </div>
            <div>
              <label style={labelStyle}>Payment Date</label>
              <input type="date" defaultValue={new Date().toISOString().split('T')[0]} style={inputStyle} />
            </div>
          </div>
          <div>
            <label style={labelStyle}>Transaction ID / Reference No</label>
            <input type="text" placeholder="e.g. UPI-ID, Bank Ref" style={inputStyle} />
          </div>
          <div>
            <label style={labelStyle}>Accountant Remarks</label>
            <textarea placeholder="e.g. Partial payment adjusted..." style={{ ...inputStyle, height: '80px' }} />
          </div>

          <div style={{ display: 'flex', gap: '1rem', marginTop: '1rem' }}>
            <button className="btn-primary" style={{ flex: 1, backgroundColor: '#7c3aed', color: 'white', padding: '1rem', borderRadius: '12px', fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem' }}>
              <Save size={18} /> Save Payment
            </button>
            <button type="button" onClick={() => setIsDrawerOpen(false)} style={{ flex: 1, backgroundColor: '#f1f5f9', color: '#64748b', padding: '1rem', borderRadius: '12px', fontWeight: 700 }}>
              Cancel
            </button>
          </div>
        </form>
      </Drawer>
    </div>
  );
};

export default Payments;
