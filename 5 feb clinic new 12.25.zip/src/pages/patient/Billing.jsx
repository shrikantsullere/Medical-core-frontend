import React, { useState } from 'react';
import { Eye, CreditCard, Download, Printer, Search, Building, User, FileText } from 'lucide-react';
import { SectionHeader } from '../../components/DashboardElements';
import { MOCK_INVOICES } from '../../data/mockData';
import Drawer from '../../components/Drawer.jsx';

const Billing = () => {
  const [selectedInv, setSelectedInv] = useState(null);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  const handleViewInvoice = (inv) => {
    setSelectedInv(inv);
    setIsDrawerOpen(true);
  };

  const labelStyle = {
    display: 'block',
    fontSize: '0.75rem',
    fontWeight: 700,
    color: '#94a3b8',
    textTransform: 'uppercase',
    marginBottom: '0.25rem'
  };

  return (
    <div className="fade-in">
      <SectionHeader title="Bills & Payments" desc="View your invoices and pay clinic dues securely." />

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>Invoice No</th>
              <th>Clinic Name</th>
              <th>Date</th>
              <th>Total Amount</th>
              <th>Paid Amount</th>
              <th>Due Amount</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {MOCK_INVOICES.map(inv => (
              <tr key={inv.id}>
                <td><span style={{ fontWeight: 600 }}>{inv.invId}</span></td>
                <td>City Dental Clinic</td>
                <td>{inv.date}</td>
                <td style={{ fontWeight: 600 }}>{inv.total}</td>
                <td style={{ color: '#10b981', fontWeight: 600 }}>{inv.paid}</td>
                <td style={{ color: inv.due !== '₹ 0' ? '#ef4444' : '#64748b', fontWeight: 700 }}>{inv.due}</td>
                <td>
                  <span className={`badge ${inv.status === 'Paid' ? 'badge-success' : inv.status === 'Partial' ? 'badge-warning' : 'badge-danger'}`}>
                    {inv.status}
                  </span>
                </td>
                <td>
                  <div style={{ display: 'flex', gap: '0.5rem' }}>
                    <button className="action-btn" onClick={() => handleViewInvoice(inv)} title="View Invoice"><Eye size={18} color="#6366f1" /></button>
                    {inv.status !== 'Paid' && (
                      <button className="action-btn" title="Pay Now"><CreditCard size={18} color="#10b981" /></button>
                    )}
                    <button className="action-btn" title="Download PDF"><Download size={18} color="#64748b" /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Drawer isOpen={isDrawerOpen} onClose={() => setIsDrawerOpen(false)} title="Invoice Details">
        {selectedInv && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
            {/* Clinic & Doctor Header */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', borderBottom: '1px solid #f1f5f9', paddingBottom: '1.5rem' }}>
              <div>
                <h3 style={{ fontSize: '1.5rem', marginBottom: '0.25rem' }}>City Dental Clinic</h3>
                <p style={{ color: '#64748b', fontSize: '0.9rem' }}>123 Clinic St, Medical Area, New Delhi</p>
                <p style={{ color: '#7c3aed', fontWeight: 700, marginTop: '0.5rem' }}>Attended by: {selectedInv.doctor}</p>
              </div>
              <div style={{ textAlign: 'right' }}>
                <p style={{ fontSize: '1.25rem', fontWeight: 800 }}>{selectedInv.invId}</p>
                <p style={{ color: '#64748b' }}>{selectedInv.date}</p>
              </div>
            </div>

            {/* Breakdown */}
            <div>
              <h4 style={{ marginBottom: '1rem', color: '#1e293b' }}>Services & Charges</h4>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', padding: '1.25rem', border: '1px solid #f1f5f9', borderRadius: '16px', backgroundColor: '#f8fafc' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ fontWeight: 600 }}>General Consultation</span>
                  <span>₹ 500.00</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ fontWeight: 600 }}>Digital X-Ray</span>
                  <span>₹ 800.00</span>
                </div>
                <hr style={{ border: 'none', borderTop: '1px dashed #e2e8f0', margin: '0.5rem 0' }} />
                <div style={{ display: 'flex', justifyContent: 'space-between', color: '#64748b' }}>
                  <span>Tax (GST 5%)</span>
                  <span>₹ 65.00</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', color: '#64748b' }}>
                  <span>Discount</span>
                  <span>- ₹ 0.00</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '1.25rem', fontWeight: 800, color: '#1e293b', marginTop: '0.5rem' }}>
                  <span>Total Payable</span>
                  <span style={{ color: '#7c3aed' }}>{selectedInv.total}</span>
                </div>
              </div>
            </div>

            <div style={{ display: 'flex', gap: '1rem', marginTop: '1rem' }}>
              {selectedInv.status !== 'Paid' && (
                <button style={{ flex: 2, backgroundColor: '#10b981', color: 'white', padding: '1rem', borderRadius: '12px', fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem' }}>
                  <CreditCard size={18} /> Pay Online Now
                </button>
              )}
              <button style={{ flex: 1, backgroundColor: '#f1f5f9', color: '#64748b', padding: '1rem', borderRadius: '12px', fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem' }}>
                <Download size={18} /> PDF
              </button>
              <button style={{ flex: 1, backgroundColor: '#f1f5f9', color: '#64748b', padding: '1rem', borderRadius: '12px', fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem' }}>
                <Printer size={18} /> Print
              </button>
            </div>
          </div>
        )}
      </Drawer>
    </div>
  );
};

export default Billing;
