import React, { useState } from 'react';
import { Eye, CheckCircle, Download, Search, Filter, Landmark, User, FileText, Calendar } from 'lucide-react';
import { SectionHeader } from '../../components/DashboardElements';
import { MOCK_DOCTOR_PAYOUTS } from '../../data/mockData';
import Drawer from '../../components/Drawer.jsx';

const DoctorPayouts = () => {
  const [selectedPayout, setSelectedPayout] = useState(null);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  const handleViewDetails = (payout) => {
    setSelectedPayout(payout);
    setIsDrawerOpen(true);
  };

  const labelStyle = {
    display: 'block',
    fontSize: '0.75rem',
    fontWeight: 700,
    color: '#94a3b8',
    textTransform: 'uppercase',
    marginBottom: '0.3rem'
  };

  return (
    <div className="fade-in">
      <SectionHeader title="Doctor Payouts" desc="Calculate and manage commission settlements for doctors." />

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>Doctor Name</th>
              <th>Total Revenue</th>
              <th>Comm %</th>
              <th>Doctor Share</th>
              <th>Paid Amount</th>
              <th>Balance</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {MOCK_DOCTOR_PAYOUTS.map(p => (
              <tr key={p.id}>
                <td><b>{p.name}</b></td>
                <td>{p.revenue}</td>
                <td>{p.commission}</td>
                <td style={{ fontWeight: 700 }}>{p.share}</td>
                <td style={{ color: '#10b981', fontWeight: 600 }}>{p.paid}</td>
                <td style={{ color: p.balance !== '₹ 0' ? '#ef4444' : '#64748b', fontWeight: 700 }}>{p.balance}</td>
                <td>
                  <span className={`badge ${p.status === 'Paid' ? 'badge-success' : 'badge-warning'}`}>
                    {p.status}
                  </span>
                </td>
                <td>
                  <div style={{ display: 'flex', gap: '0.5rem' }}>
                    <button className="action-btn" title="View Details" onClick={() => handleViewDetails(p)}><Eye size={18} color="#6366f1" /></button>
                    <button className="action-btn" title="Mark as Paid"><CheckCircle size={18} color="#10b981" /></button>
                    <button className="action-btn" title="Download Statement"><Download size={18} color="#64748b" /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Drawer isOpen={isDrawerOpen} onClose={() => setIsDrawerOpen(false)} title="Payout Statement">
        {selectedPayout && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
            <div style={{ backgroundColor: '#f8fafc', padding: '1.5rem', borderRadius: '16px', border: '1px solid #e2e8f0', display: 'flex', alignItems: 'center', gap: '1rem' }}>
              <div style={{ width: '60px', height: '60px', borderRadius: '15px', backgroundColor: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', border: '1px solid #e2e8f0' }}>
                <User size={30} color="#7c3aed" />
              </div>
              <div>
                <h3 style={{ fontSize: '1.25rem' }}>{selectedPayout.name}</h3>
                <p style={{ color: '#64748b', fontSize: '0.9rem' }}>Period: 01 March - 31 March 2024</p>
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <div className="card" style={{ padding: '1rem' }}>
                <label style={labelStyle}>Total Consultations</label>
                <p style={{ fontSize: '1.25rem', fontWeight: 800 }}>48</p>
              </div>
              <div className="card" style={{ padding: '1rem' }}>
                <label style={labelStyle}>Total Revenue</label>
                <p style={{ fontSize: '1.25rem', fontWeight: 800 }}>{selectedPayout.revenue}</p>
              </div>
              <div className="card" style={{ padding: '1rem' }}>
                <label style={labelStyle}>Commission %</label>
                <p style={{ fontSize: '1.25rem', fontWeight: 800 }}>{selectedPayout.commission}</p>
              </div>
              <div className="card" style={{ padding: '1rem', backgroundColor: '#f5f3ff', border: '1px solid #ddd6fe' }}>
                <label style={{ ...labelStyle, color: '#7c3aed' }}>Net Payable</label>
                <p style={{ fontSize: '1.25rem', fontWeight: 800, color: '#7c3aed' }}>{selectedPayout.share}</p>
              </div>
            </div>

            <div>
              <h4 style={{ marginBottom: '1rem' }}>Linked Invoices</h4>
              <div style={{ border: '1px solid #f1f5f9', borderRadius: '12px', padding: '1rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.9rem', marginBottom: '0.5rem', color: '#64748b' }}>
                  <span>INV-5001 (Deepak Verma)</span><span>₹ 500.00</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.9rem', marginBottom: '0.5rem', color: '#64748b' }}>
                  <span>INV-5003 (Raj Kumar)</span><span>₹ 1,200.00</span>
                </div>
                <hr style={{ border: 'none', borderTop: '1px dashed #e2e8f0', margin: '0.5rem 0' }} />
                <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 700 }}>
                  <span>Sub-Total Share</span><span>{selectedPayout.share}</span>
                </div>
              </div>
            </div>

            <div style={{ display: 'flex', gap: '1rem' }}>
              <button style={{ flex: 1, backgroundColor: '#10b981', color: 'white', padding: '1rem', borderRadius: '12px', fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem' }}>
                <CheckCircle size={18} /> Mark as Paid
              </button>
              <button style={{ flex: 1, backgroundColor: '#f1f5f9', color: '#64748b', padding: '1rem', borderRadius: '12px', fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem' }}>
                <Download size={18} /> Download PDF
              </button>
            </div>
          </div>
        )}
      </Drawer>
    </div>
  );
};

export default DoctorPayouts;
