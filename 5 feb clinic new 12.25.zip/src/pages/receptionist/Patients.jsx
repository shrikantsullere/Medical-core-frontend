import React, { useState } from 'react';
import { Eye, Edit, Search, Filter, Calendar, FileText, UserPlus, Phone, Mail, MapPin } from 'lucide-react';
import { SectionHeader } from '../../components/DashboardElements';
import { MOCK_PATIENTS, MOCK_APPOINTMENTS, MOCK_INVOICES } from '../../data/mockData';
import Drawer from '../../components/Drawer.jsx';

const Patients = () => {
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [viewType, setViewType] = useState('list'); // list, add, view
  const [activeTab, setActiveTab] = useState('Personal Info');
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');

  const filteredPatients = MOCK_PATIENTS.filter(patient => {
    const matchesSearch = patient.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      patient.patientId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      patient.mobile.includes(searchTerm);
    const matchesStatus = statusFilter === 'All' || patient.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleAddPatient = () => {
    setViewType('add');
    setSelectedPatient(null);
    setIsDrawerOpen(true);
  };

  const handleViewProfile = (patient) => {
    setViewType('view');
    setSelectedPatient(patient);
    setActiveTab('Personal Info');
    setIsDrawerOpen(true);
  };

  const labelStyle = {
    display: 'block',
    fontSize: '0.8rem',
    fontWeight: 700,
    color: 'var(--text-muted)',
    textTransform: 'uppercase',
    marginBottom: '0.4rem'
  };

  const inputStyle = {
    width: '100%',
    padding: '0.75rem',
    borderRadius: '10px',
    border: '1px solid #e2e8f0',
    fontSize: '0.9rem',
    outline: 'none',
  };

  return (
    <div className="fade-in">
      <SectionHeader
        title="Patients"
        desc="Manage patient registrations and records."
        actionLabel="Add Patient"
        onAction={handleAddPatient}
      />

      <div className="card" style={{ marginBottom: '1.5rem', padding: '1rem', backgroundColor: 'var(--bg-sidebar)' }}>
        <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
          <div style={{ flex: 1, minWidth: '250px', position: 'relative' }}>
            <Search size={18} color="#94a3b8" style={{ position: 'absolute', left: '1rem', top: '50%', transform: 'translateY(-50%)' }} />
            <input
              type="text"
              placeholder="Search by name, ID or mobile..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              style={{ ...inputStyle, paddingLeft: '2.8rem', backgroundColor: 'var(--bg-main)', color: 'var(--text-main)' }}
            />
          </div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            style={{ padding: '0 1rem', borderRadius: '10px', border: '1px solid #e2e8f0', backgroundColor: 'var(--bg-main)', color: 'var(--text-main)', outline: 'none', height: '44px' }}
          >
            <option value="All">All Status</option>
            <option value="Active">Active</option>
            <option value="Inactive">Inactive</option>
          </select>
        </div>
      </div>

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>Patient ID</th>
              <th>Patient Name</th>
              <th>Mobile</th>
              <th>Gender</th>
              <th>Last Visit</th>
              <th>Due Amount</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {filteredPatients.map(patient => (
              <tr key={patient.id}>
                <td><span style={{ fontWeight: 600, color: '#64748b' }}>{patient.patientId}</span></td>
                <td><b>{patient.name}</b></td>
                <td>{patient.mobile}</td>
                <td>{patient.gender}</td>
                <td>{patient.lastVisit}</td>
                <td style={{ color: patient.dueAmount !== '₹ 0' ? '#ef4444' : '#10b981', fontWeight: 700 }}>{patient.dueAmount}</td>
                <td>
                  <span className={`badge ${patient.status === 'Active' ? 'badge-success' : 'badge-danger'}`}>
                    {patient.status}
                  </span>
                </td>
                <td>
                  <div style={{ display: 'flex', gap: '0.5rem' }}>
                    <button className="action-btn" onClick={() => handleViewProfile(patient)} title="View Profile"><Eye size={18} color="#7c3aed" /></button>
                    <button className="action-btn" title="Edit"><Edit size={18} color="#3b82f6" /></button>
                    <button className="action-btn" title="Book Appointment"><Calendar size={18} color="#0ea5e9" /></button>
                    <button className="action-btn" title="Create Invoice"><FileText size={18} color="#10b981" /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Drawer
        isOpen={isDrawerOpen}
        onClose={() => setIsDrawerOpen(false)}
        title={viewType === 'add' ? "Add Patient" : "Patient Profile"}
      >
        {viewType === 'add' ? (
          <form style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <div style={{ gridColumn: 'span 2' }}>
                <label style={labelStyle}>Full Name *</label>
                <input type="text" placeholder="Full Name" style={inputStyle} required />
              </div>
              <div>
                <label style={labelStyle}>Mobile Number *</label>
                <input type="tel" placeholder="Mobile Number" style={inputStyle} required />
              </div>
              <div>
                <label style={labelStyle}>Email</label>
                <input type="email" placeholder="Email" style={inputStyle} />
              </div>
              <div>
                <label style={labelStyle}>Gender</label>
                <select style={inputStyle}>
                  <option>Male</option>
                  <option>Female</option>
                  <option>Other</option>
                </select>
              </div>
              <div>
                <label style={labelStyle}>DOB / Age</label>
                <input type="text" placeholder="DOB or Age" style={inputStyle} />
              </div>
              <div style={{ gridColumn: 'span 2' }}>
                <label style={labelStyle}>Address</label>
                <textarea placeholder="Full Address" style={{ ...inputStyle, height: '60px' }} />
              </div>
              <div style={{ gridColumn: 'span 2' }}>
                <label style={labelStyle}>Emergency Contact Name</label>
                <input type="text" placeholder="Contact Name" style={inputStyle} />
              </div>
              <div style={{ gridColumn: 'span 2' }}>
                <label style={labelStyle}>Emergency Contact Number</label>
                <input type="tel" placeholder="Contact Number" style={inputStyle} />
              </div>
            </div>
            <div style={{ display: 'flex', gap: '1rem', marginTop: '1rem' }}>
              <button className="btn-primary" style={{ flex: 1, backgroundColor: '#7c3aed', color: 'white', padding: '1rem', borderRadius: '12px', fontWeight: 700 }}>Save</button>
              <button className="btn-secondary" style={{ flex: 1, backgroundColor: '#f5f3ff', color: '#7c3aed', padding: '1rem', borderRadius: '12px', fontWeight: 600 }}>Save & Book Appointment</button>
              <button type="button" onClick={() => setIsDrawerOpen(false)} style={{ backgroundColor: '#fee2e2', color: '#ef4444', padding: '1rem', borderRadius: '12px', fontWeight: 600 }}>Cancel</button>
            </div>
          </form>
        ) : selectedPatient && (
          <div>
            <div style={{ display: 'flex', gap: '1.5rem', alignItems: 'center', marginBottom: '2rem' }}>
              <div style={{ width: '70px', height: '70px', borderRadius: '20px', backgroundColor: 'var(--bg-header)', color: 'var(--primary)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.75rem', fontWeight: 800 }}>
                {selectedPatient.name.charAt(0)}
              </div>
              <div>
                <h2 style={{ fontSize: '1.5rem', color: 'var(--heading)' }}>{selectedPatient.name}</h2>
                <p style={{ color: 'var(--text-muted)', fontWeight: 600 }}>ID: {selectedPatient.patientId}</p>
              </div>
            </div>

            <div style={{ display: 'flex', gap: '1rem', borderBottom: '1px solid var(--border)', marginBottom: '1.5rem' }}>
              {['Personal Info', 'Appointment History', 'Bills & Payments'].map(tab => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  style={{
                    padding: '0.75rem 0.5rem',
                    color: activeTab === tab ? 'var(--primary)' : 'var(--text-muted)',
                    borderBottom: `2px solid ${activeTab === tab ? 'var(--primary)' : 'transparent'}`,
                    fontWeight: 600,
                    fontSize: '0.9rem',
                    backgroundColor: 'transparent'
                  }}
                >
                  {tab}
                </button>
              ))}
            </div>

            <div>
              {activeTab === 'Personal Info' && (
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
                  <div><label style={labelStyle}>Gender</label><p style={{ fontWeight: 600 }}>{selectedPatient.gender}</p></div>
                  <div><label style={labelStyle}>Age</label><p style={{ fontWeight: 600 }}>{selectedPatient.age} years</p></div>
                  <div style={{ gridColumn: 'span 2' }}><label style={labelStyle}>Address</label><p style={{ fontWeight: 600 }}>Medical Area, New Delhi</p></div>
                </div>
              )}
              {activeTab === 'Appointment History' && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                  {MOCK_APPOINTMENTS.map(app => (
                    <div key={app.id} style={{ padding: '1rem', border: '1px solid #f1f5f9', borderRadius: '12px' }}>
                      <p style={{ fontWeight: 700 }}>{app.date} • {app.time}</p>
                      <p style={{ fontSize: '0.85rem', color: '#64748b' }}>{app.doctor} • {app.type}</p>
                    </div>
                  ))}
                </div>
              )}
              {activeTab === 'Bills & Payments' && (
                <div>
                  {MOCK_INVOICES.map(inv => (
                    <div key={inv.id} style={{ padding: '1rem', border: '1px solid #f1f5f9', borderRadius: '12px', marginBottom: '0.75rem', display: 'flex', justifyContent: 'space-between' }}>
                      <div>
                        <p style={{ fontWeight: 700 }}>{inv.invId}</p>
                        <p style={{ color: '#64748b' }}>{inv.date}</p>
                      </div>
                      <p style={{ fontWeight: 800 }}>{inv.total}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </Drawer>
    </div>
  );
};

export default Patients;
