import React from 'react';
import { SectionHeader, EmptyState } from '../../components/DashboardElements';
const Profile = () => <div className="fade-in"><SectionHeader title="Profile Settings" desc="Manage availability and password." /><EmptyState message="Settings form." /></div>;
export default Profile;
