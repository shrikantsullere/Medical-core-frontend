import React, { useState } from 'react';
import { Eye, Edit, Trash2, Plus, Check, Play, Square, Circle, Shield, Star, DollarSign, Users } from 'lucide-react';
import { SectionHeader } from '../../components/DashboardElements';
import { MOCK_PLANS } from '../../data/mockData';
import Drawer from '../../components/Drawer.jsx';

const Plans = () => {
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState(null);
  const [viewType, setViewType] = useState('add');

  const inputStyle = {
    width: '100%',
    padding: '0.75rem',
    borderRadius: '10px',
    border: '1px solid #e2e8f0',
    fontSize: '0.9rem',
    outline: 'none',
  };

  const labelStyle = {
    display: 'block',
    fontSize: '0.8rem',
    fontWeight: 700,
    color: '#475569',
    marginBottom: '0.5rem',
    textTransform: 'uppercase',
  };

  const handleViewPlan = (plan) => {
    setSelectedPlan(plan);
    setViewType('view');
    setIsDrawerOpen(true);
  };

  return (
    <div className="fade-in">
      <SectionHeader
        title="Subscription Plans"
        desc="Create and manage clinic subscription packages."
        actionLabel="Create Plan"
        onAction={() => { setViewType('add'); setSelectedPlan(null); setIsDrawerOpen(true); }}
      />

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>Plan Name</th>
              <th>Cycle</th>
              <th>Price</th>
              <th>Doctors</th>
              <th>Staff</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {MOCK_PLANS.map(plan => (
              <tr key={plan.id}>
                <td data-label="Plan Name"><b>{plan.name}</b></td>
                <td data-label="Cycle">{plan.cycle}</td>
                <td data-label="Price">{plan.price}</td>
                <td data-label="Doctors">{plan.doctors}</td>
                <td data-label="Staff">{plan.staff}</td>
                <td data-label="Status">
                  <span className={`badge ${plan.status === 'Active' ? 'badge-success' : 'badge-danger'}`}>
                    {plan.status}
                  </span>
                </td>
                <td data-label="Actions">
                  <div style={{ display: 'flex', gap: '0.5rem' }}>
                    <button className="action-btn" title="View Features" onClick={() => handleViewPlan(plan)}><Eye size={18} color="var(--primary)" /></button>
                    <button className="action-btn" title="Edit" onClick={() => { setSelectedPlan(plan); setViewType('add'); setIsDrawerOpen(true); }}><Edit size={18} color="var(--secondary)" /></button>
                    <button className="action-btn" title={plan.status === 'Active' ? 'Disable' : 'Enable'} onClick={() => confirm(`Are you sure you want to ${plan.status === 'Active' ? 'disable' : 'enable'} this plan?`) && alert('Plan status updated.')}>
                      {plan.status === 'Active' ? <Square size={16} color="var(--danger)" /> : <Play size={16} color="#10b981" />}
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Drawer isOpen={isDrawerOpen} onClose={() => setIsDrawerOpen(false)} title={viewType === 'add' ? "New Subscription Plan" : "Plan Features"}>
        {viewType === 'add' ? (
          <form style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
            <div>
              <label style={labelStyle}>Plan Name</label>
              <input type="text" placeholder="e.g. Standard Monthly" style={inputStyle} />
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <div>
                <label style={labelStyle}>Billing Cycle</label>
                <select style={inputStyle}>
                  <option>Monthly</option>
                  <option>Yearly</option>
                </select>
              </div>
              <div>
                <label style={labelStyle}>Price ($)</label>
                <input type="text" placeholder="5000" style={inputStyle} />
              </div>
            </div>
            {/* ... rest of add form ... */}
            <div style={{ display: 'flex', gap: '1rem', marginTop: '1rem' }}>
              <button className="btn-primary" style={{ flex: 1, backgroundColor: 'var(--primary)', color: 'white', padding: '1rem', borderRadius: '12px', fontWeight: 700 }}>Save Plan</button>
              <button type="button" onClick={() => setIsDrawerOpen(false)} style={{ padding: '1rem 1.5rem', borderRadius: '12px', color: 'var(--danger)', border: '1px solid #fee2e2' }}>Cancel</button>
            </div>
          </form>
        ) : selectedPlan && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
            <div style={{ backgroundColor: 'var(--bg-header)', padding: '2rem', borderRadius: '24px', textAlign: 'center' }}>
              <Star size={40} color="var(--primary)" style={{ marginBottom: '1rem' }} />
              <h2 style={{ fontSize: '1.75rem' }}>{selectedPlan.name}</h2>
              <p style={{ fontSize: '1.5rem', fontWeight: 800, color: 'var(--primary)', marginTop: '0.5rem' }}>{selectedPlan.price} <span style={{ fontSize: '0.9rem', color: 'var(--text-muted)' }}>/{selectedPlan.cycle}</span></p>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <div className="card" style={{ padding: '1rem', background: 'white', border: '1px solid var(--border)' }}>
                <Users size={20} color="var(--primary)" style={{ marginBottom: '0.5rem' }} />
                <label style={{ fontSize: '0.7rem', fontWeight: 700, color: '#94a3b8' }}>DOCTORS</label>
                <p style={{ fontWeight: 800 }}>{selectedPlan.doctors} Limit</p>
              </div>
              <div className="card" style={{ padding: '1rem', background: 'white', border: '1px solid var(--border)' }}>
                <Shield size={20} color="var(--primary)" style={{ marginBottom: '0.5rem' }} />
                <label style={{ fontSize: '0.7rem', fontWeight: 700, color: '#94a3b8' }}>STAFF</label>
                <p style={{ fontWeight: 800 }}>{selectedPlan.staff} Limit</p>
              </div>
            </div>

            <div>
              <h4 style={{ marginBottom: '1rem' }}>Included Features</h4>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                {['Online Billing', 'Patient Records (EMR)', 'Prescription Management', 'Receptionist Portal', 'Financial Reports'].map(f => (
                  <div key={f} style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', padding: '0.75rem', borderRadius: '12px', background: '#f8fafc' }}>
                    <div style={{ width: '20px', height: '20px', borderRadius: '50%', background: '#dcfce7', color: '#166534', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                      <Check size={14} strokeWidth={3} />
                    </div>
                    <span style={{ fontWeight: 600, fontSize: '0.9rem' }}>{f}</span>
                  </div>
                ))}
              </div>
            </div>

            <button className="btn-primary" style={{ width: '100%', padding: '1rem', marginTop: '1rem' }}>Edit Plan Features</button>
          </div>
        )}
      </Drawer>
    </div>
  );
};

export default Plans;
