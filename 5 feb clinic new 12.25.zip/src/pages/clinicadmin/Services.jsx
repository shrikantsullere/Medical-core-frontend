import React, { useState } from 'react';
import { Plus, Search, Tag, DollarSign, Edit, Ban } from 'lucide-react';
import { SectionHeader } from '../../components/DashboardElements';
import { MOCK_SERVICES } from '../../data/mockData';
import Drawer from '../../components/Drawer.jsx';

const Services = () => {
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  const inputStyle = {
    width: '100%',
    padding: '0.75rem',
    borderRadius: '10px',
    border: '1px solid #e2e8f0',
    fontSize: '0.9rem',
    outline: 'none',
  };

  const labelStyle = {
    display: 'block',
    fontSize: '0.8rem',
    fontWeight: 700,
    color: '#475569',
    marginBottom: '0.4rem',
    textTransform: 'uppercase',
  };

  return (
    <div className="fade-in">
      <SectionHeader
        title="Services & Charges"
        desc="Manage clinic services and pricing."
        actionLabel="Add Service"
        onAction={() => setIsDrawerOpen(true)}
      />

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>Service Name</th>
              <th>Price</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {MOCK_SERVICES.map(service => (
              <tr key={service.id}>
                <td>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                    <div style={{ width: '32px', height: '32px', borderRadius: '8px', backgroundColor: '#f0fdf4', color: '#10b981', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                      <Tag size={16} />
                    </div>
                    <b>{service.name}</b>
                  </div>
                </td>
                <td style={{ fontWeight: 700 }}>{service.price}</td>
                <td>
                  <span className={`badge ${service.status === 'Active' ? 'badge-success' : 'badge-danger'}`}>
                    {service.status}
                  </span>
                </td>
                <td>
                  <div style={{ display: 'flex', gap: '0.5rem' }}>
                    <button className="action-btn" title="Edit"><Edit size={16} color="#3b82f6" /></button>
                    <button className="action-btn" title="Disable"><Ban size={16} color="#ef4444" /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Drawer isOpen={isDrawerOpen} onClose={() => setIsDrawerOpen(false)} title="Add Service">
        <form style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          <div>
            <label style={labelStyle}>Service Name *</label>
            <input type="text" placeholder="e.g. Consultation" style={inputStyle} required />
          </div>
          <div>
            <label style={labelStyle}>Description</label>
            <textarea placeholder="Service details..." style={{ ...inputStyle, height: '80px', resize: 'none' }} />
          </div>
          <div>
            <label style={labelStyle}>Default Price ($) *</label>
            <input type="number" placeholder="500" style={inputStyle} required />
          </div>

          <button className="btn-primary" style={{ backgroundColor: '#7c3aed', color: 'white', padding: '1rem', borderRadius: '12px', fontWeight: 700, marginTop: '1rem' }}>Save</button>
        </form>
      </Drawer>
    </div>
  );
};

export default Services;
