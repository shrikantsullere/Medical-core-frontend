import React from 'react';
import { Download, FileText, TrendingUp, Users, Wallet, Filter, Calendar, Briefcase, BarChart3 } from 'lucide-react';
import { SectionHeader } from '../../components/DashboardElements';

const Reports = () => {
  const reports = [
    { title: 'Daily Collection Report', desc: 'Summary of all bills and collections for today.', icon: TrendingUp },
    { title: 'Monthly Revenue Report', desc: 'Detailed financial performance month-over-month.', icon: BarChart3 },
    { title: 'Pending Dues Report', desc: 'List of patients and insurance with outstanding dues.', icon: Briefcase },
    { title: 'Expense Report', desc: 'Breakdown of clinic operational expenses.', icon: Wallet },
    { title: 'Doctor Commission Report', desc: 'Payouts and revenue share per doctor.', icon: Users },
    { title: 'GST Report', desc: 'Summary of GST collected for tax filing.', icon: FileText },
  ];

  const inputStyle = {
    padding: '0.6rem 1rem',
    borderRadius: '10px',
    border: '1px solid #e2e8f0',
    fontSize: '0.9rem',
    outline: 'none',
    backgroundColor: 'white'
  };

  return (
    <div className="fade-in">
      <SectionHeader title="Financial Reports" desc="Export detailed audits and financial summaries." />

      {/* Filters */}
      <div className="card" style={{ marginBottom: '2rem', padding: '1.25rem' }}>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '1.5rem', alignItems: 'flex-end' }}>
          <div>
            <label style={{ fontSize: '0.75rem', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', display: 'block', marginBottom: '0.5rem' }}>Date Range</label>
            <input type="date" style={inputStyle} />
          </div>
          <div>
            <label style={{ fontSize: '0.75rem', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', display: 'block', marginBottom: '0.5rem' }}>Doctor</label>
            <select style={inputStyle}>
              <option>All Doctors</option>
              <option>Dr. Sameer Khan</option>
              <option>Dr. Anjali Rao</option>
            </select>
          </div>
          <div>
            <label style={{ fontSize: '0.75rem', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', display: 'block', marginBottom: '0.5rem' }}>Mode</label>
            <select style={inputStyle}>
              <option>All Modes</option>
              <option>Cash</option>
              <option>UPI</option>
              <option>Online</option>
            </select>
          </div>
          <button style={{ height: '42px', backgroundColor: '#7c3aed', color: 'white', padding: '0 1.5rem', borderRadius: '10px', display: 'flex', alignItems: 'center', gap: '0.5rem', fontWeight: 600 }}>
            <Filter size={18} /> Apply Filters
          </button>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(350px, 1fr))', gap: '1.5rem' }}>
        {reports.map((r, i) => (
          <div key={i} className="card" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', transition: 'all 0.2s', cursor: 'pointer' }}>
            <div style={{ display: 'flex', gap: '1.25rem', alignItems: 'center' }}>
              <div style={{ width: '56px', height: '56px', borderRadius: '14px', backgroundColor: '#f8fafc', color: '#6366f1', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <r.icon size={28} />
              </div>
              <div>
                <h4 style={{ fontSize: '1.1rem' }}>{r.title}</h4>
                <p style={{ fontSize: '0.85rem', color: '#64748b' }}>{r.desc}</p>
              </div>
            </div>
            <div style={{ display: 'flex', gap: '0.5rem' }}>
              <button className="action-btn" title="Download PDF"><Download size={18} color="#ef4444" /></button>
              <button className="action-btn" title="Export Excel"><Briefcase size={18} color="#10b981" /></button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Reports;
