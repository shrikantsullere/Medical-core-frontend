import React, { useState } from 'react';
import { Settings as SettingsIcon, Bell, Shield, Eye, Save, Globe, Landmark, FileText, CreditCard, Upload } from 'lucide-react';
import { SectionHeader } from '../../components/DashboardElements';

const Settings = () => {
  const [activeTab, setActiveTab] = useState('clinic');

  const inputStyle = {
    width: '100%',
    padding: '0.75rem',
    borderRadius: '10px',
    border: '1px solid #e2e8f0',
    fontSize: '0.9rem',
    outline: 'none',
  };

  const labelStyle = {
    display: 'block',
    fontSize: '0.8rem',
    fontWeight: 700,
    color: '#475569',
    marginBottom: '0.4rem',
    textTransform: 'uppercase',
  };

  const cardStyle = {
    backgroundColor: 'white',
    borderRadius: '20px',
    padding: '2rem',
    border: '1px solid #e2e8f0',
    boxShadow: '0 4px 6px -1px rgba(0,0,0,0.05)'
  };

  return (
    <div className="fade-in">
      <SectionHeader title="Settings" desc="Configure your clinic's profile and preferences." />

      <div style={{ display: 'flex', gap: '1rem', marginBottom: '2rem', flexWrap: 'wrap' }}>
        {[
          { id: 'clinic', label: 'Clinic Settings', icon: Landmark },
          { id: 'tax', label: 'Tax / GST', icon: FileText },
          { id: 'invoice', label: 'Invoice Template', icon: CreditCard },
          { id: 'gateway', label: 'Payment Gateway', icon: Shield },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '0.6rem',
              padding: '0.8rem 1.5rem',
              borderRadius: '12px',
              backgroundColor: activeTab === tab.id ? '#7c3aed' : 'white',
              color: activeTab === tab.id ? 'white' : '#64748b',
              fontWeight: 600,
              border: activeTab === tab.id ? 'none' : '1px solid #e2e8f0',
              transition: 'all 0.2s'
            }}
          >
            <tab.icon size={18} />
            {tab.label}
          </button>
        ))}
      </div>

      <div style={{ maxWidth: '800px' }}>
        {activeTab === 'clinic' && (
          <div className="fade-in" style={cardStyle}>
            <h3 style={{ marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '0.75rem' }}><Landmark /> Profile Information</h3>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
              <div style={{ gridColumn: 'span 2' }}>
                <label style={labelStyle}>Clinic Name</label>
                <input type="text" defaultValue="City Dental Clinic" style={inputStyle} />
              </div>
              <div style={{ gridColumn: 'span 2' }}>
                <label style={labelStyle}>Full Address</label>
                <textarea defaultValue="123 Clinic St, Medical Area, New Delhi" style={{ ...inputStyle, height: '80px' }} />
              </div>
              <div>
                <label style={labelStyle}>Contact Email</label>
                <input type="email" defaultValue="admin@citydental.com" style={inputStyle} />
              </div>
              <div>
                <label style={labelStyle}>Contact Number</label>
                <input type="tel" defaultValue="9876543210" style={inputStyle} />
              </div>
              <button style={{ gridColumn: 'span 2', backgroundColor: '#7c3aed', color: 'white', padding: '1rem', borderRadius: '12px', fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem', marginTop: '1rem' }}>
                <Save size={18} /> Save Profile
              </button>
            </div>
          </div>
        )}

        {activeTab === 'tax' && (
          <div className="fade-in" style={cardStyle}>
            <h3 style={{ marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '0.75rem' }}><FileText /> Tax Configuration</h3>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
              <div>
                <label style={labelStyle}>GST Number</label>
                <input type="text" placeholder="27AAAAA0000A1Z5" style={inputStyle} />
              </div>
              <div>
                <label style={labelStyle}>Tax Percentage (%)</label>
                <input type="number" defaultValue="18" style={inputStyle} />
              </div>
              <button style={{ backgroundColor: '#7c3aed', color: 'white', padding: '1rem', borderRadius: '12px', fontWeight: 700, marginTop: '1rem' }}>
                Save Settings
              </button>
            </div>
          </div>
        )}

        {activeTab === 'invoice' && (
          <div className="fade-in" style={cardStyle}>
            <h3 style={{ marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '0.75rem' }}><CreditCard /> Branding & Invoice Template</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
              <div>
                <label style={labelStyle}>Clinic Logo</label>
                <div style={{ border: '2px dashed #e2e8f0', borderRadius: '12px', padding: '1.5rem', textAlign: 'center', color: '#94a3b8' }}>
                  <Upload size={24} style={{ marginBottom: '0.5rem' }} />
                  <p style={{ fontSize: '0.85rem' }}>Update Logo</p>
                </div>
              </div>
              <div>
                <label style={labelStyle}>Header Text</label>
                <input type="text" placeholder="e.g. Your health, our priority" style={inputStyle} />
              </div>
              <div>
                <label style={labelStyle}>Footer Text</label>
                <input type="text" placeholder="e.g. Visit again for your follow-up" style={inputStyle} />
              </div>
              <div>
                <label style={labelStyle}>Terms & Conditions</label>
                <textarea placeholder="1. Fees not refundable..." style={{ ...inputStyle, height: '100px' }} />
              </div>
              <button style={{ backgroundColor: '#7c3aed', color: 'white', padding: '1rem', borderRadius: '12px', fontWeight: 700 }}>
                Save Template
              </button>
            </div>
          </div>
        )}

        {activeTab === 'gateway' && (
          <div className="fade-in" style={cardStyle}>
            <h3 style={{ marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '0.75rem' }}><Shield /> Online Payments</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '1rem', backgroundColor: '#f8fafc', borderRadius: '12px' }}>
                <div>
                  <h4 style={{ fontSize: '1rem', marginBottom: '0.25rem' }}>Enable Online Payments</h4>
                  <p style={{ fontSize: '0.8rem', color: '#64748b' }}>Allow patients to pay bills via UPI/Card.</p>
                </div>
                <input type="checkbox" style={{ width: '40px', height: '20px', cursor: 'pointer' }} defaultChecked />
              </div>
              <div>
                <label style={labelStyle}>API Keys (Locked by Super Admin)</label>
                <input type="text" value="************************" style={{ ...inputStyle, backgroundColor: '#f1f5f9', cursor: 'not-allowed' }} readOnly />
              </div>
              <p style={{ fontSize: '0.8rem', color: '#ef4444', backgroundColor: '#fee2e2', padding: '0.75rem', borderRadius: '8px' }}>
                Note: Only the Super Admin can update the Payment Gateway credentials for your safety.
              </p>
              <button style={{ backgroundColor: '#7c3aed', color: 'white', padding: '1rem', borderRadius: '12px', fontWeight: 700 }}>Save Changes</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Settings;
