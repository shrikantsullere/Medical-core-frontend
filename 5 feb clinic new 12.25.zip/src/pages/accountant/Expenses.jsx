import React, { useState } from 'react';
import { Wallet, Plus, Search, Filter, Edit, Trash2, Eye, Calendar, Upload, Save } from 'lucide-react';
import { SectionHeader } from '../../components/DashboardElements';
import { MOCK_EXPENSES } from '../../data/mockData';
import Drawer from '../../components/Drawer.jsx';

const Expenses = () => {
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  const labelStyle = {
    display: 'block',
    fontSize: '0.75rem',
    fontWeight: 700,
    color: '#94a3b8',
    textTransform: 'uppercase',
    marginBottom: '0.3rem'
  };

  const inputStyle = {
    width: '100%',
    padding: '0.75rem',
    borderRadius: '10px',
    border: '1px solid #e2e8f0',
    fontSize: '0.9rem',
    outline: 'none',
  };

  return (
    <div className="fade-in">
      <SectionHeader
        title="Expense Management"
        desc="Track clinic overheads, salaries, and utility bills."
        actionLabel="Add Expense"
        onAction={() => setIsDrawerOpen(true)}
      />

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>Date</th>
              <th>Category</th>
              <th>Description</th>
              <th>Amount</th>
              <th>Mode</th>
              <th>Added By</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {MOCK_EXPENSES.map(exp => (
              <tr key={exp.id}>
                <td>{exp.date}</td>
                <td><span className="badge badge-blue">{exp.category}</span></td>
                <td>{exp.description}</td>
                <td style={{ fontWeight: 700, color: '#ef4444' }}>{exp.amount}</td>
                <td>{exp.mode}</td>
                <td><span style={{ fontSize: '0.85rem', color: '#64748b' }}>{exp.addedBy}</span></td>
                <td>
                  <div style={{ display: 'flex', gap: '0.5rem' }}>
                    <button className="action-btn" title="View Bill"><Eye size={16} color="#6366f1" /></button>
                    <button className="action-btn" title="Edit"><Edit size={16} color="#f59e0b" /></button>
                    <button className="action-btn" title="Delete"><Trash2 size={16} color="#ef4444" /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Drawer isOpen={isDrawerOpen} onClose={() => setIsDrawerOpen(false)} title="Add Expense">
        <form style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
            <div>
              <label style={labelStyle}>Expense Category *</label>
              <select style={inputStyle} required>
                <option>Rent</option>
                <option>Salary</option>
                <option>Utilities</option>
                <option>Supplies</option>
                <option>Other</option>
              </select>
            </div>
            <div>
              <label style={labelStyle}>Expense Date *</label>
              <input type="date" style={inputStyle} defaultValue={new Date().toISOString().split('T')[0]} required />
            </div>
          </div>
          <div>
            <label style={labelStyle}>Description *</label>
            <input type="text" placeholder="e.g. Electricity bill for March" style={inputStyle} required />
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
            <div>
              <label style={labelStyle}>Amount ($) *</label>
              <input type="number" placeholder="0.00" style={inputStyle} required />
            </div>
            <div>
              <label style={labelStyle}>Payment Mode</label>
              <select style={inputStyle}>
                <option>Online</option>
                <option>Bank Transfer</option>
                <option>UPI</option>
                <option>Cash</option>
              </select>
            </div>
          </div>
          <div>
            <label style={labelStyle}>Attachment (Upload Bill)</label>
            <div style={{ border: '2px dashed #e2e8f0', borderRadius: '12px', padding: '1.5rem', textAlign: 'center', color: '#94a3b8' }}>
              <Upload size={24} style={{ marginBottom: '0.5rem' }} />
              <p style={{ fontSize: '0.8rem' }}>Drag or click to upload receipt</p>
            </div>
          </div>
          <div style={{ display: 'flex', gap: '1rem', marginTop: '1rem' }}>
            <button className="btn-primary" style={{ flex: 1, backgroundColor: '#7c3aed', color: 'white', padding: '1rem', borderRadius: '12px', fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem' }}>
              <Save size={18} /> Save Expense
            </button>
            <button type="button" onClick={() => setIsDrawerOpen(false)} style={{ flex: 1, backgroundColor: '#f1f5f9', color: '#64748b', padding: '1rem', borderRadius: '12px', fontWeight: 700 }}>
              Cancel
            </button>
          </div>
        </form>
      </Drawer>
    </div>
  );
};

export default Expenses;
