import React, { useState } from 'react';
import { Eye, Printer, Send, Search, Plus, Trash2 } from 'lucide-react';
import { SectionHeader } from '../../components/DashboardElements';
import { MOCK_INVOICES, MOCK_PATIENTS, MOCK_DOCTORS, MOCK_SERVICES } from '../../data/mockData';
import Drawer from '../../components/Drawer.jsx';

const Billing = () => {
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  const labelStyle = {
    display: 'block',
    fontSize: '0.75rem',
    fontWeight: 700,
    color: '#94a3b8',
    textTransform: 'uppercase',
    marginBottom: '0.3rem'
  };

  const inputStyle = {
    width: '100%',
    padding: '0.75rem',
    borderRadius: '10px',
    border: '1px solid #e2e8f0',
    fontSize: '0.9rem',
    outline: 'none',
  };

  return (
    <div className="fade-in">
      <SectionHeader
        title="Billing & Invoices"
        desc="Generate bills and manage clinic invoices."
        actionLabel="Create Invoice"
        onAction={() => setIsDrawerOpen(true)}
      />

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>Invoice No</th>
              <th>Patient Name</th>
              <th>Date</th>
              <th>Total Amount</th>
              <th>Paid Amount</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {MOCK_INVOICES.map(inv => (
              <tr key={inv.id}>
                <td><span style={{ fontWeight: 600 }}>{inv.invId}</span></td>
                <td><b>{inv.patient}</b></td>
                <td>{inv.date}</td>
                <td>{inv.total}</td>
                <td style={{ color: '#10b981', fontWeight: 700 }}>{inv.paid}</td>
                <td><span className={`badge ${inv.status === 'Paid' ? 'badge-success' : 'badge-warning'}`}>{inv.status}</span></td>
                <td>
                  <div style={{ display: 'flex', gap: '0.5rem' }}>
                    <button className="action-btn" title="View"><Eye size={16} color="#6366f1" /></button>
                    <button className="action-btn" title="Print"><Printer size={16} color="#64748b" /></button>

                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Drawer isOpen={isDrawerOpen} onClose={() => setIsDrawerOpen(false)} title="Create Invoice">
        <form style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
            <div>
              <label style={labelStyle}>Patient *</label>
              <select style={inputStyle}>
                <option>Select Patient</option>
                {MOCK_PATIENTS.map(p => <option key={p.id}>{p.name}</option>)}
              </select>
            </div>
            <div>
              <label style={labelStyle}>Doctor *</label>
              <select style={inputStyle}>
                {MOCK_DOCTORS.map(d => <option key={d.id}>{d.name}</option>)}
              </select>
            </div>
          </div>
          <div>
            <label style={labelStyle}>Services / Items</label>
            <div style={{ padding: '1rem', border: '1px solid #e2e8f0', borderRadius: '12px', backgroundColor: '#f8fafc' }}>
              <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 0.5fr', gap: '0.5rem', marginBottom: '0.5rem', fontSize: '0.7rem', fontWeight: 700, color: '#94a3b8' }}>
                <span>SERVICE</span><span>PRICE</span><span>QTY</span><span></span>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 0.5fr', gap: '0.5rem', marginBottom: '0.5rem' }}>
                <select style={{ ...inputStyle, padding: '0.4rem' }}>{MOCK_SERVICES.map(s => <option key={s.id}>{s.name}</option>)}</select>
                <input type="number" defaultValue="500" style={{ ...inputStyle, padding: '0.4rem' }} />
                <input type="number" defaultValue="1" style={{ ...inputStyle, padding: '0.4rem' }} />
                <button type="button" style={{ color: '#ef4444' }}><Trash2 size={16} /></button>
              </div>
              <button style={{ fontSize: '0.85rem', color: '#7c3aed', fontWeight: 600, display: 'flex', alignItems: 'center', gap: '0.25rem', marginTop: '0.5rem', backgroundColor: 'transparent' }}>
                <Plus size={14} /> Add Another Item
              </button>
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
            <div><label style={labelStyle}>Discount ($)</label><input type="number" defaultValue="0" style={inputStyle} /></div>
            <div><label style={labelStyle}>Tax (GST %)</label><input type="number" defaultValue="18" style={inputStyle} /></div>
          </div>
          <div style={{ backgroundColor: '#f5f3ff', padding: '1.25rem', borderRadius: '12px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontWeight: 700, color: '#4c1d95' }}>Final Amount</span>
            <span style={{ fontSize: '1.25rem', fontWeight: 800, color: '#7c3aed' }}>$ 590.00</span>
          </div>
          <div style={{ display: 'flex', gap: '1rem' }}>
            <button className="btn-primary" style={{ flex: 1, backgroundColor: '#7c3aed', color: 'white', padding: '1rem', borderRadius: '12px', fontWeight: 700 }}>Save Invoice</button>
            <button className="btn-secondary" style={{ flex: 1, backgroundColor: '#f0fdf4', color: '#10b981', padding: '1rem', borderRadius: '12px', fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem' }}>
              <Printer size={18} /> Save & Print
            </button>
          </div>
        </form>
      </Drawer>
    </div>
  );
};

export default Billing;
