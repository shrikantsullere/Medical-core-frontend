import React, { useState } from 'react';
import { DollarSign, Printer, Save, Plus } from 'lucide-react';
import { SectionHeader } from '../../components/DashboardElements';
import { MOCK_PAYMENTS, MOCK_INVOICES } from '../../data/mockData';
import Drawer from '../../components/Drawer.jsx';

const Payments = () => {
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  const inputStyle = {
    width: '100%',
    padding: '0.75rem',
    borderRadius: '10px',
    border: '1px solid #e2e8f0',
    fontSize: '0.9rem',
    outline: 'none',
  };

  const labelStyle = {
    display: 'block',
    fontSize: '0.8rem',
    fontWeight: 700,
    color: '#475569',
    marginBottom: '0.4rem',
    textTransform: 'uppercase',
  };

  return (
    <div className="fade-in">
      <SectionHeader
        title="Payments"
        desc="Track patient collections and receipts."
        actionLabel="Collect Payment"
        onAction={() => setIsDrawerOpen(true)}
      />

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>Receipt No</th>
              <th>Invoice No</th>
              <th>Patient</th>
              <th>Amount</th>
              <th>Payment Mode</th>
              <th>Date</th>
            </tr>
          </thead>
          <tbody>
            {MOCK_PAYMENTS.map(pay => (
              <tr key={pay.id}>
                <td><span style={{ fontWeight: 600, color: '#6366f1' }}>{pay.txId}</span></td>
                <td><span style={{ color: '#64748b' }}>{pay.invId}</span></td>
                <td><b>{pay.clinic}</b></td>
                <td style={{ fontWeight: 700 }}>{pay.amount}</td>
                <td><span className="badge badge-blue">{pay.mode}</span></td>
                <td>{pay.date}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Drawer isOpen={isDrawerOpen} onClose={() => setIsDrawerOpen(false)} title="Collect Payment">
        <form style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          <div>
            <label style={labelStyle}>Invoice No *</label>
            <select style={inputStyle} required>
              <option value="">Select Invoice</option>
              {MOCK_INVOICES.filter(inv => inv.status !== 'Paid').map(inv => (
                <option key={inv.id}>{inv.invId} - {inv.patient} ({inv.total})</option>
              ))}
            </select>
          </div>
          <div>
            <label style={labelStyle}>Amount to Collect ($) *</label>
            <input type="number" placeholder="500" style={inputStyle} required />
          </div>
          <div>
            <label style={labelStyle}>Payment Mode *</label>
            <select style={inputStyle} required>
              <option>Cash</option>
              <option>UPI</option>
              <option>Card</option>
              <option>Online</option>
            </select>
          </div>
          <div>
            <label style={labelStyle}>Transaction ID / Ref No</label>
            <input type="text" placeholder="TXN12345..." style={inputStyle} />
          </div>
          <div>
            <label style={labelStyle}>Payment Date</label>
            <input type="date" defaultValue={new Date().toISOString().split('T')[0]} style={inputStyle} />
          </div>

          <div style={{ display: 'flex', gap: '1rem', marginTop: '1rem' }}>
            <button className="btn-primary" style={{ flex: 1, backgroundColor: '#7c3aed', color: 'white', padding: '1rem', borderRadius: '12px', fontWeight: 700 }}>Save Payment</button>
            <button type="button" style={{ flex: 1, backgroundColor: '#f1f5f9', color: '#64748b', padding: '1rem', borderRadius: '12px', fontWeight: 600, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem' }}>
              <Printer size={18} /> Print Receipt
            </button>
          </div>
        </form>
      </Drawer>
    </div>
  );
};

export default Payments;
