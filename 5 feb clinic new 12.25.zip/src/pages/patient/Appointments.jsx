import React, { useState } from 'react';
import { Eye, XCircle, RefreshCw, Calendar as CalendarIcon, Clock, Search, Plus } from 'lucide-react';
import { SectionHeader } from '../../components/DashboardElements';
import { MOCK_APPOINTMENTS, MOCK_DOCTORS, MOCK_CLINICS } from '../../data/mockData';
import Drawer from '../../components/Drawer.jsx';

const Appointments = () => {
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [selectedAppt, setSelectedAppt] = useState(null);

  const labelStyle = {
    display: 'block',
    fontSize: '0.75rem',
    fontWeight: 700,
    color: '#94a3b8',
    textTransform: 'uppercase',
    marginBottom: '0.3rem'
  };

  const inputStyle = {
    width: '100%',
    padding: '0.75rem',
    borderRadius: '10px',
    border: '1px solid #e2e8f0',
    fontSize: '0.9rem',
    outline: 'none',
  };

  return (
    <div className="fade-in">
      <SectionHeader
        title="My Appointments"
        desc="Track your upcoming and previous clinic visits."
        actionLabel="Book Appointment"
        onAction={() => setIsDrawerOpen(true)}
      />

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>Appt ID</th>
              <th>Doctor Name</th>
              <th>Clinic Name</th>
              <th>Date</th>
              <th>Time Slot</th>
              <th>Visit Type</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {MOCK_APPOINTMENTS.map(appt => (
              <tr key={appt.id}>
                <td><span style={{ fontWeight: 600, color: '#64748b' }}>{appt.appId}</span></td>
                <td><b>{appt.doctor}</b></td>
                <td>City Dental Clinic</td>
                <td>{appt.date}</td>
                <td>{appt.time}</td>
                <td><span className="badge badge-blue">{appt.type}</span></td>
                <td><span className={`badge ${appt.status === 'Completed' ? 'badge-success' : appt.status === 'Confirmed' ? 'badge-blue' : 'badge-warning'}`}>{appt.status}</span></td>
                <td>
                  <div style={{ display: 'flex', gap: '0.5rem' }}>
                    <button className="action-btn" title="View Details"><Eye size={18} color="#6366f1" /></button>
                    {appt.status !== 'Completed' && (
                      <>
                       
                        <button className="action-btn" title="Cancel Appointment"><XCircle size={18} color="#ef4444" /></button>
                      </>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Drawer isOpen={isDrawerOpen} onClose={() => setIsDrawerOpen(false)} title="Book Appointment">
        <form style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          <div>
            <label style={labelStyle}>Select Clinic</label>
            <select style={inputStyle}>
              {MOCK_CLINICS.map(c => <option key={c.id}>{c.name}</option>)}
            </select>
          </div>
          <div>
            <label style={labelStyle}>Select Doctor</label>
            <select style={inputStyle}>
              {MOCK_DOCTORS.map(d => <option key={d.id}>{d.name}</option>)}
            </select>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
            <div>
              <label style={labelStyle}>Appointment Date</label>
              <input type="date" style={inputStyle} />
            </div>
            <div>
              <label style={labelStyle}>Time Slot</label>
              <input type="time" style={inputStyle} />
            </div>
          </div>
          <div>
            <label style={labelStyle}>Visit Type</label>
            <select style={inputStyle}>
              <option>New Visit</option>
              <option>Follow-up</option>
            </select>
          </div>
          <div>
            <label style={labelStyle}>Problem Description (Optional)</label>
            <textarea placeholder="Tell us about your symptoms or reason for visit..." style={{ ...inputStyle, height: '100px' }} />
          </div>

          <div style={{ display: 'flex', gap: '1rem', marginTop: '1rem' }}>
            <button className="btn-primary" style={{ flex: 1, backgroundColor: '#7c3aed', color: 'white', padding: '1rem', borderRadius: '14px', fontWeight: 700 }}>
              Book Appointment
            </button>
            <button type="button" onClick={() => setIsDrawerOpen(false)} style={{ flex: 1, backgroundColor: '#f1f5f9', color: '#64748b', padding: '1rem', borderRadius: '12px', fontWeight: 700 }}>
              Cancel
            </button>
          </div>
        </form>
      </Drawer>
    </div>
  );
};

export default Appointments;
