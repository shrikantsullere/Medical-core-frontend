import React from 'react';
import { DollarSign, Download, Filter, FileBarChart, TrendingUp, Calendar } from 'lucide-react';
import { StatCard, SectionHeader } from '../../components/DashboardElements';
import { MOCK_EARNINGS } from '../../data/mockData';

const Earnings = () => {
  return (
    <div className="fade-in">
      <SectionHeader title="My Earnings" desc="Transparent reporting of your consultations and commissions." />

      {/* Summary Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '1.5rem', marginBottom: '2rem' }}>
        <StatCard title="Today Earnings" value="$ 4,500" color="#10b981" icon={DollarSign} />
        <StatCard title="Monthly Earnings" value="$ 125,000" color="#3b82f6" icon={TrendingUp} />
        <StatCard title="Total Career Earnings" value="$ 145K" color="#8b5cf6" icon={FileBarChart} />
      </div>

      {/* Filters & Export */}
      <div className="card" style={{ marginBottom: '1.5rem', padding: '1rem' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
          <div style={{ display: 'flex', gap: '1rem' }}>
            <div style={{ position: 'relative' }}>
              <Calendar size={18} color="#94a3b8" style={{ position: 'absolute', left: '1rem', top: '50%', transform: 'translateY(-50%)' }} />
              <input type="text" placeholder="Date Range" style={{ padding: '0.6rem 1rem 0.6rem 2.8rem', borderRadius: '10px', border: '1px solid #e2e8f0', outline: 'none', fontSize: '0.9rem' }} onFocus={(e) => e.target.type = 'date'} />
            </div>
            <select style={{ padding: '0.6rem 1rem', borderRadius: '10px', border: '1px solid #e2e8f0', outline: 'none', fontSize: '0.9rem', backgroundColor: 'white' }}>
              <option>Applied Clinic (Self)</option>
            </select>
          </div>
          <div style={{ display: 'flex', gap: '0.75rem' }}>
            <button style={{ height: '40px', padding: '0 1rem', borderRadius: '10px', backgroundColor: '#fee2e2', color: '#ef4444', fontWeight: 600, display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <Download size={18} /> PDF
            </button>
            <button style={{ height: '40px', padding: '0 1rem', borderRadius: '10px', backgroundColor: '#f0fdf4', color: '#10b981', fontWeight: 600, display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <Download size={18} /> Excel
            </button>
          </div>
        </div>
      </div>

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>Date</th>
              <th>Patient</th>
              <th>Service</th>
              <th>Amount ($)</th>
              <th>Commission %</th>
              <th>Doctor Share ($)</th>
            </tr>
          </thead>
          <tbody>
            {MOCK_EARNINGS.map(item => (
              <tr key={item.id}>
                <td>{item.date}</td>
                <td><b>{item.patient}</b></td>
                <td><span className="badge badge-blue">{item.service}</span></td>
                <td style={{ fontWeight: 600 }}>{item.amount}</td>
                <td>{item.commission}%</td>
                <td style={{ fontWeight: 800, color: '#10b981' }}>$ {item.share}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Earnings;
