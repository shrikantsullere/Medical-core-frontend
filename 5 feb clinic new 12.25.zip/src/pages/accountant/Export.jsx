import React from 'react';
import { SectionHeader, EmptyState } from '../../components/DashboardElements';
const Export = () => <div className="fade-in"><SectionHeader title="Export Center" desc="Download files in Excel/PDF format." /><EmptyState message="Excel data download." /></div>;
export default Export;
